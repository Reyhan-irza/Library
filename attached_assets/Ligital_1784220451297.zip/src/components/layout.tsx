import { useLocation, Link } from "wouter";
import {
  LayoutDashboard, BookOpen, ArrowLeftRight, BarChart3, User,
  Menu, X, Settings, Users, BookMarked, Layers, Heart,
  Bell, AlertTriangle, Clock, ChevronRight, LogOut, Shield,
} from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { useState } from "react";
import { cn } from "@/lib/utils";
import { useGetNotifications } from "@workspace/api-client-react";
import { getUser, clearToken } from "@/lib/auth";
import { useLocation as useWouterLocation } from "wouter";
import AnimatedBackground from "@/components/animated-bg";

const navItems = [
  { path: "/dashboard",  label: "Beranda",  icon: LayoutDashboard },
  { path: "/books",      label: "Buku",     icon: BookOpen },
  { path: "/borrowings", label: "Pinjam",   icon: ArrowLeftRight },
  { path: "/favorites",  label: "Favorit",  icon: Heart },
  { path: "/profile",    label: "Profil",   icon: User },
];

const sidebarItems = [
  { path: "/dashboard",  label: "Dashboard",    icon: LayoutDashboard },
  { path: "/books",      label: "Buku",          icon: BookOpen },
  { path: "/borrowings", label: "Peminjaman",    icon: ArrowLeftRight },
  { path: "/favorites",  label: "Buku Favorit",  icon: Heart },
  { path: "/reports",    label: "Laporan",       icon: BarChart3 },
  { section: "Manajemen" },
  { path: "/members",    label: "Anggota",       icon: Users },
  { path: "/categories", label: "Kategori",      icon: Layers },
  { path: "/racks",      label: "Rak Buku",      icon: BookMarked },
  { path: "/staff",      label: "Petugas",       icon: Settings },
  { path: "/profile",    label: "Profil",        icon: User },
];

function SidebarLink({
  item, active, onClick,
}: {
  item: { path: string; label: string; icon: React.ElementType };
  active: boolean;
  onClick?: () => void;
}) {
  const Icon = item.icon;
  const isFavorite = item.path === "/favorites";
  return (
    <Link href={item.path}>
      <motion.div
        onClick={onClick}
        whileHover={{ x: 3, transition: { duration: 0.15 } }}
        whileTap={{ scale: 0.97 }}
        className={cn(
          "flex items-center gap-3 px-3 py-2.5 rounded-xl cursor-pointer transition-all duration-200 text-sm font-medium group",
          active
            ? isFavorite
              ? "bg-rose-500/15 text-rose-500 shadow-sm"
              : "bg-primary text-primary-foreground shadow-sm shadow-primary/25"
            : "text-muted-foreground hover:bg-accent hover:text-foreground",
        )}
      >
        <Icon
          size={17}
          className="flex-shrink-0 transition-transform duration-200 group-hover:scale-105"
          {...(isFavorite && active ? { fill: "currentColor" } : {})}
        />
        <span className="flex-1">{item.label}</span>
        {active && (
          <motion.div
            layoutId="sidebar-active-dot"
            className={cn("w-1.5 h-1.5 rounded-full flex-shrink-0", isFavorite ? "bg-rose-500/60" : "bg-primary-foreground/60")}
            transition={{ type: "spring", stiffness: 400, damping: 30 }}
          />
        )}
      </motion.div>
    </Link>
  );
}

function NotificationPanel({ onClose }: { onClose: () => void }) {
  const { data } = useGetNotifications();
  const notifications = data?.items ?? [];

  return (
    <motion.div
      initial={{ opacity: 0, y: 8, scale: 0.96 }}
      animate={{ opacity: 1, y: 0, scale: 1 }}
      exit={{ opacity: 0, y: 8, scale: 0.96 }}
      transition={{ duration: 0.2, ease: [0.23, 1, 0.32, 1] }}
      className="absolute right-0 top-full mt-2 w-80 bg-card/95 backdrop-blur-xl border border-border/60 rounded-2xl shadow-2xl shadow-black/15 z-50 overflow-hidden"
    >
      <div className="flex items-center justify-between px-4 py-3 border-b border-border/60">
        <h3 className="text-sm font-semibold text-foreground">Notifikasi</h3>
        <div className="flex items-center gap-2">
          {notifications.length > 0 && (
            <span className="text-[10px] text-muted-foreground bg-muted px-2 py-0.5 rounded-full">
              {notifications.length}
            </span>
          )}
          <button onClick={onClose} className="p-1 rounded-lg hover:bg-accent transition-colors">
            <X size={13} className="text-muted-foreground" />
          </button>
        </div>
      </div>
      <div className="max-h-80 overflow-y-auto">
        {notifications.length === 0 ? (
          <div className="flex flex-col items-center py-10 text-center px-4">
            <div className="w-12 h-12 rounded-2xl bg-muted/50 flex items-center justify-center mb-3">
              <Bell size={20} className="text-muted-foreground/30" />
            </div>
            <p className="text-xs font-medium text-muted-foreground">Tidak ada notifikasi</p>
            <p className="text-[10px] text-muted-foreground/60 mt-0.5">Semua peminjaman dalam kondisi baik</p>
          </div>
        ) : (
          notifications.slice(0, 8).map((n, i) => (
            <motion.div
              key={n.id}
              initial={{ opacity: 0, x: -8 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: i * 0.04 }}
              className="flex items-start gap-3 px-4 py-3 hover:bg-accent/50 transition-colors border-b border-border/40 last:border-0"
            >
              <div className={cn(
                "w-7 h-7 rounded-xl flex items-center justify-center flex-shrink-0 mt-0.5",
                n.type === "overdue"
                  ? "bg-rose-500/10 text-rose-500"
                  : "bg-amber-500/10 text-amber-500",
              )}>
                {n.type === "overdue" ? <AlertTriangle size={12} /> : <Clock size={12} />}
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-xs font-semibold text-foreground">{n.title}</p>
                <p className="text-[11px] text-muted-foreground mt-0.5 line-clamp-2">{n.message}</p>
              </div>
              {!n.read && (
                <div className="w-2 h-2 rounded-full bg-rose-500 flex-shrink-0 mt-1.5" />
              )}
            </motion.div>
          ))
        )}
      </div>
      {notifications.length > 0 && (
        <div className="px-4 py-2.5 border-t border-border/60 bg-muted/20">
          <Link href="/borrowings">
            <button onClick={onClose} className="text-xs text-primary font-medium flex items-center gap-1 hover:opacity-80 transition-opacity">
              Lihat semua peminjaman <ChevronRight size={11} />
            </button>
          </Link>
        </div>
      )}
    </motion.div>
  );
}

function UserFooter({ onLogout }: { onLogout: () => void }) {
  const user = getUser();
  const roleLabel =
    user?.role === "admin" ? "Administrator" :
    user?.role === "librarian" ? "Pustakawan" : "Petugas";
  const initial = (user?.name || user?.username || "A").charAt(0).toUpperCase();

  return (
    <div className="p-3 border-t border-border/50">
      <div className="group flex items-center gap-3 p-2.5 rounded-xl hover:bg-accent/60 transition-all duration-200 cursor-default">
        <div className="w-8 h-8 rounded-xl bg-gradient-to-br from-primary/20 to-primary/10 flex items-center justify-center flex-shrink-0 border border-primary/20">
          <span className="text-primary font-bold text-sm leading-none">{initial}</span>
        </div>
        <div className="flex-1 min-w-0">
          <p className="text-xs font-semibold text-foreground truncate">{user?.name || user?.username || "Admin"}</p>
          <div className="flex items-center gap-1 mt-0.5">
            <Shield size={9} className="text-primary/60" />
            <p className="text-[10px] text-muted-foreground">{roleLabel}</p>
          </div>
        </div>
        <motion.button
          whileTap={{ scale: 0.9 }}
          onClick={onLogout}
          className="p-1.5 rounded-lg text-muted-foreground hover:text-rose-500 hover:bg-rose-500/10 transition-all duration-200 opacity-0 group-hover:opacity-100"
          title="Keluar"
        >
          <LogOut size={13} />
        </motion.button>
      </div>
    </div>
  );
}

export default function Layout({ children }: { children: React.ReactNode }) {
  const [location] = useLocation();
  const [, setLocation] = useWouterLocation();
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [notifOpen, setNotifOpen] = useState(false);

  const { data: notifData } = useGetNotifications();
  const unreadCount = notifData?.unreadCount ?? 0;

  function isActive(path: string) {
    if (path === "/dashboard") return location === "/dashboard" || location === "/";
    return location === path || location.startsWith(path + "/");
  }

  function handleLogout() {
    clearToken();
    setLocation("/login");
  }

  return (
    <div className="min-h-screen bg-background flex relative">
      <AnimatedBackground />

      {/* ── Desktop Sidebar ── */}
      <aside className="hidden md:flex flex-col w-64 fixed h-full z-20 glass-sidebar">
        <div className="p-5 border-b border-border/50">
          <Link href="/dashboard">
            <motion.div
              whileHover={{ scale: 1.02, transition: { duration: 0.15 } }}
              className="flex items-center gap-3 cursor-pointer"
            >
              <div className="w-9 h-9 rounded-xl bg-primary flex items-center justify-center shadow-lg shadow-primary/30 flex-shrink-0">
                <BookOpen className="w-5 h-5 text-primary-foreground" />
              </div>
              <div>
                <h1 className="text-sm font-bold text-foreground leading-tight">
                  Perpustakaan SMKN 2
                </h1>
                <p className="text-[10px] text-muted-foreground">Lubuk Basung</p>
              </div>
            </motion.div>
          </Link>
        </div>

        <nav className="flex-1 p-3 space-y-0.5 overflow-y-auto">
          {sidebarItems.map((item, i) => {
            if ("section" in item) {
              return (
                <p key={i} className="text-[10px] font-bold text-muted-foreground/50 uppercase tracking-widest pt-5 pb-2 px-3">
                  {item.section}
                </p>
              );
            }
            return (
              <SidebarLink
                key={item.path}
                item={item as { path: string; label: string; icon: React.ElementType }}
                active={isActive(item.path!)}
              />
            );
          })}
        </nav>

        <UserFooter onLogout={handleLogout} />
      </aside>

      {/* ── Mobile Overlay Sidebar ── */}
      <AnimatePresence>
        {sidebarOpen && (
          <>
            <motion.div
              initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
              transition={{ duration: 0.2 }}
              className="fixed inset-0 bg-black/60 backdrop-blur-md z-30 md:hidden"
              onClick={() => setSidebarOpen(false)}
            />
            <motion.aside
              initial={{ x: -288 }} animate={{ x: 0 }} exit={{ x: -288 }}
              transition={{ type: "spring", stiffness: 340, damping: 34 }}
              className="fixed left-0 top-0 h-full w-72 z-40 md:hidden flex flex-col glass-sidebar"
            >
              <div className="p-5 border-b border-border/50 flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-9 h-9 rounded-xl bg-primary flex items-center justify-center shadow-lg shadow-primary/30">
                    <BookOpen className="w-5 h-5 text-primary-foreground" />
                  </div>
                  <div>
                    <h1 className="text-sm font-bold text-foreground leading-tight">Perpustakaan SMKN 2</h1>
                    <p className="text-[10px] text-muted-foreground">Lubuk Basung</p>
                  </div>
                </div>
                <button
                  onClick={() => setSidebarOpen(false)}
                  className="p-1.5 rounded-xl hover:bg-accent transition-colors"
                  aria-label="Tutup menu"
                >
                  <X size={16} className="text-muted-foreground" />
                </button>
              </div>

              <nav className="flex-1 p-3 space-y-0.5 overflow-y-auto">
                {sidebarItems.map((item, i) => {
                  if ("section" in item) {
                    return (
                      <p key={i} className="text-[10px] font-bold text-muted-foreground/50 uppercase tracking-widest pt-5 pb-2 px-3">
                        {item.section}
                      </p>
                    );
                  }
                  return (
                    <SidebarLink
                      key={item.path}
                      item={item as { path: string; label: string; icon: React.ElementType }}
                      active={isActive(item.path!)}
                      onClick={() => setSidebarOpen(false)}
                    />
                  );
                })}
              </nav>

              <UserFooter onLogout={handleLogout} />
            </motion.aside>
          </>
        )}
      </AnimatePresence>

      {/* ── Main Content ── */}
      <main className="flex-1 md:ml-64 flex flex-col min-h-screen relative z-10">

        {/* Mobile Header */}
        <header className="md:hidden sticky top-0 z-20 glass border-b border-border/40 px-4 py-3 flex items-center justify-between">
          <motion.button
            whileTap={{ scale: 0.92 }}
            onClick={() => setSidebarOpen(true)}
            className="p-2 rounded-xl hover:bg-accent transition-colors"
            aria-label="Buka menu"
          >
            <Menu size={19} className="text-foreground" />
          </motion.button>
          <div className="flex items-center gap-2">
            <div className="w-7 h-7 rounded-lg bg-primary flex items-center justify-center shadow-md shadow-primary/25">
              <BookOpen className="w-3.5 h-3.5 text-primary-foreground" />
            </div>
            <span className="font-bold text-foreground text-sm">
              SMKN 2 Lubuk Basung
            </span>
          </div>
          <div className="relative">
            <motion.button
              whileTap={{ scale: 0.9 }}
              onClick={() => setNotifOpen(v => !v)}
              className="w-9 h-9 rounded-xl bg-muted flex items-center justify-center hover:bg-accent transition-colors relative"
              aria-label="Notifikasi"
            >
              <Bell size={16} className="text-muted-foreground" />
              {unreadCount > 0 && (
                <motion.span
                  initial={{ scale: 0 }}
                  animate={{ scale: 1 }}
                  className="absolute -top-0.5 -right-0.5 w-4 h-4 bg-rose-500 text-white rounded-full text-[9px] flex items-center justify-center font-bold leading-none"
                >
                  {unreadCount > 9 ? "9+" : unreadCount}
                </motion.span>
              )}
            </motion.button>
            <AnimatePresence>
              {notifOpen && (
                <>
                  <div className="fixed inset-0 z-40" onClick={() => setNotifOpen(false)} />
                  <div className="relative z-50">
                    <NotificationPanel onClose={() => setNotifOpen(false)} />
                  </div>
                </>
              )}
            </AnimatePresence>
          </div>
        </header>

        {/* Page Content */}
        <div className="flex-1 overflow-auto pb-24 md:pb-0">
          {children}
        </div>

        {/* ── Bottom Navigation (Mobile) ── */}
        <nav className="md:hidden fixed bottom-0 left-0 right-0 z-20 glass border-t border-border/40">
          <div className="flex items-center justify-around px-1 py-1.5">
            {navItems.map((item) => {
              const Icon = item.icon;
              const active = isActive(item.path);
              const isFavorite = item.path === "/favorites";
              return (
                <Link key={item.path} href={item.path}>
                  <motion.div
                    data-testid={`nav-${item.path.replace("/", "")}`}
                    whileTap={{ scale: 0.88 }}
                    className="relative flex flex-col items-center justify-center px-3 py-1.5 cursor-pointer min-w-[56px]"
                  >
                    <AnimatePresence>
                      {active && (
                        <motion.div
                          layoutId="nav-capsule"
                          className={cn("absolute inset-0 rounded-2xl", isFavorite ? "bg-rose-500/10" : "bg-primary/10")}
                          initial={{ opacity: 0, scale: 0.8 }}
                          animate={{ opacity: 1, scale: 1 }}
                          exit={{ opacity: 0, scale: 0.8 }}
                          transition={{ type: "spring", stiffness: 450, damping: 32 }}
                        />
                      )}
                    </AnimatePresence>

                    <motion.div
                      animate={{ y: active ? -3 : 0 }}
                      transition={{ type: "spring", stiffness: 450, damping: 28 }}
                      className="relative"
                    >
                      <Icon
                        size={18}
                        {...(isFavorite && active ? { fill: "currentColor" } : {})}
                        className={cn(
                          "transition-colors duration-200",
                          active
                            ? isFavorite ? "text-rose-500" : "text-primary"
                            : "text-muted-foreground",
                        )}
                      />
                      {active && (
                        <motion.span
                          initial={{ opacity: 0, scale: 0 }}
                          animate={{ opacity: 1, scale: 1 }}
                          className={cn("absolute -bottom-1 left-1/2 -translate-x-1/2 w-1 h-1 rounded-full", isFavorite ? "bg-rose-500" : "bg-primary")}
                        />
                      )}
                    </motion.div>

                    <motion.span
                      animate={{ opacity: active ? 1 : 0.6 }}
                      className={cn(
                        "text-[9px] font-semibold mt-0.5 transition-colors duration-200",
                        active
                          ? isFavorite ? "text-rose-500" : "text-primary"
                          : "text-muted-foreground",
                      )}
                    >
                      {item.label}
                    </motion.span>
                  </motion.div>
                </Link>
              );
            })}
          </div>
        </nav>
      </main>
    </div>
  );
}
