import { useState } from "react";
import { useLocation } from "wouter";
import { motion } from "framer-motion";
import { BookOpen, Eye, EyeOff, Loader2 } from "lucide-react";
import { useLogin } from "@workspace/api-client-react";
import { setToken } from "@/lib/auth";
import { toast } from "sonner";
import AnimatedBackground from "@/components/animated-bg";

export default function LoginPage() {
  const [, setLocation] = useLocation();
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);

  const loginMutation = useLogin({
    mutation: {
      onSuccess: (data) => {
        setToken(data.token);
        toast.success("Login berhasil!");
        setLocation("/dashboard");
      },
      onError: () => {
        toast.error("Username atau password salah");
      },
    },
  });

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!username || !password) {
      toast.error("Harap isi username dan password");
      return;
    }
    loginMutation.mutate({ data: { username, password } });
  }

  return (
    <div className="min-h-screen bg-background flex items-center justify-center relative overflow-hidden p-4">
      <AnimatedBackground />

      {/* Decorative floating shapes */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none z-0">
        <motion.div
          className="absolute top-16 left-16 w-12 h-12 rounded-2xl border border-primary/15 bg-primary/5"
          animate={{ rotate: [0, 10, 0], y: [0, -8, 0] }}
          transition={{ duration: 6, repeat: Infinity, ease: "easeInOut" }}
        />
        <motion.div
          className="absolute bottom-24 right-24 w-8 h-8 rounded-xl border border-secondary/20 bg-secondary/5"
          animate={{ rotate: [0, -10, 0], y: [0, 8, 0] }}
          transition={{ duration: 5, repeat: Infinity, ease: "easeInOut", delay: 1 }}
        />
        <motion.div
          className="absolute top-1/2 right-16 w-6 h-6 rounded-lg border border-primary/15 bg-primary/5"
          animate={{ y: [0, -12, 0] }}
          transition={{ duration: 4, repeat: Infinity, ease: "easeInOut", delay: 0.5 }}
        />
        <motion.div
          className="absolute top-1/4 left-1/3 w-4 h-4 rounded-full bg-primary/10"
          animate={{ y: [0, 8, 0], x: [0, 5, 0] }}
          transition={{ duration: 7, repeat: Infinity, ease: "easeInOut", delay: 2 }}
        />
      </div>

      <div className="w-full max-w-sm relative z-10">
        {/* Logo + School Name */}
        <motion.div
          className="flex flex-col items-center mb-8"
          initial={{ scale: 0.95, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ duration: 0.6, ease: [0.34, 1.56, 0.64, 1] }}
        >
          <div className="relative mb-4">
            <div className="w-16 h-16 rounded-2xl bg-primary flex items-center justify-center shadow-lg shadow-primary/30">
              <BookOpen className="w-8 h-8 text-primary-foreground" />
            </div>
            <motion.div
              className="absolute -inset-2 rounded-3xl border-2 border-primary/20"
              animate={{ scale: [1, 1.08, 1], opacity: [0.5, 0.2, 0.5] }}
              transition={{ duration: 3, repeat: Infinity, ease: "easeInOut" }}
            />
          </div>
          <motion.div
            initial={{ y: 12, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ delay: 0.15, duration: 0.5 }}
            className="text-center"
          >
            <h1 className="text-xl font-bold text-foreground leading-tight">
              Perpustakaan SMKN 2
            </h1>
            <p className="text-base font-semibold text-primary mt-0.5">
              Lubuk Basung
            </p>
            <p className="text-xs text-muted-foreground mt-1">Sistem Informasi Perpustakaan</p>
          </motion.div>
        </motion.div>

        {/* Login Card */}
        <motion.div
          className="bg-card/90 backdrop-blur-sm border border-border/60 rounded-3xl shadow-2xl shadow-black/8 overflow-hidden"
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.25, duration: 0.5 }}
        >
          <div className="p-7">
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.35 }}>
              <h2 className="text-lg font-semibold text-foreground mb-1">
                Masuk ke Akun
              </h2>
              <p className="text-sm text-muted-foreground mb-6">Gunakan kredensial petugas perpustakaan</p>
            </motion.div>

            <form onSubmit={handleSubmit} className="space-y-4">
              <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.4 }}>
                <label className="block text-sm font-medium text-foreground mb-1.5">Username</label>
                <input
                  data-testid="input-username"
                  type="text"
                  value={username}
                  onChange={e => setUsername(e.target.value)}
                  placeholder="Masukkan username"
                  autoComplete="username"
                  className="w-full px-4 py-3 bg-background border border-border rounded-2xl text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/30 focus:border-primary transition-all duration-200"
                />
              </motion.div>

              <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.45 }}>
                <label className="block text-sm font-medium text-foreground mb-1.5">Password</label>
                <div className="relative">
                  <input
                    data-testid="input-password"
                    type={showPassword ? "text" : "password"}
                    value={password}
                    onChange={e => setPassword(e.target.value)}
                    placeholder="Masukkan password"
                    autoComplete="current-password"
                    className="w-full px-4 py-3 pr-11 bg-background border border-border rounded-2xl text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/30 focus:border-primary transition-all duration-200"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(v => !v)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground transition-colors p-1"
                    aria-label={showPassword ? "Sembunyikan password" : "Tampilkan password"}
                  >
                    {showPassword ? <EyeOff size={16} /> : <Eye size={16} />}
                  </button>
                </div>
              </motion.div>

              <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.5 }}>
                <motion.button
                  data-testid="button-login"
                  type="submit"
                  disabled={loginMutation.isPending}
                  whileHover={{ scale: loginMutation.isPending ? 1 : 1.02 }}
                  whileTap={{ scale: loginMutation.isPending ? 1 : 0.98 }}
                  className="w-full py-3 bg-primary text-primary-foreground rounded-2xl text-sm font-semibold shadow-sm shadow-primary/20 hover:bg-primary/90 disabled:opacity-70 transition-all duration-200 flex items-center justify-center gap-2"
                >
                  {loginMutation.isPending ? (
                    <>
                      <Loader2 size={16} className="animate-spin" />
                      <span>Memproses...</span>
                    </>
                  ) : "Masuk"}
                </motion.button>
              </motion.div>
            </form>
          </div>

          <div className="px-7 pb-5">
            <div className="bg-muted/50 rounded-2xl p-3">
              <p className="text-xs text-muted-foreground font-medium text-center">Demo: admin / admin</p>
            </div>
          </div>
        </motion.div>

        {/* Footer */}
        <motion.div
          className="text-center mt-6 space-y-1"
          initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.65 }}
        >
          <p className="text-xs text-muted-foreground">
            Perpustakaan SMKN 2 Lubuk Basung &copy; {new Date().getFullYear()}
          </p>
          <p className="text-[11px] text-muted-foreground/60">
            Dikembangkan oleh <span className="font-medium text-muted-foreground">Reyhan Irza Alvano</span>
          </p>
        </motion.div>
      </div>
    </div>
  );
}
