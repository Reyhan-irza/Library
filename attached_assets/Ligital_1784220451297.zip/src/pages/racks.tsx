import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Plus, BookMarked, X, Loader2, Trash2, Edit2, MapPin } from "lucide-react";
import { useListRacks, useCreateRack, useUpdateRack, useDeleteRack, getListRacksQueryKey } from "@workspace/api-client-react";
import type { Rack } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import Layout from "@/components/layout";

function RackModal({ open, onClose, rack }: { open: boolean; onClose: () => void; rack?: Rack }) {
  const qc = useQueryClient();
  const createMutation = useCreateRack({ mutation: { onSuccess: () => { qc.invalidateQueries({ queryKey: getListRacksQueryKey() }); toast.success("Rak ditambahkan"); onClose(); }, onError: () => toast.error("Gagal menambahkan rak") } });
  const updateMutation = useUpdateRack({ mutation: { onSuccess: () => { qc.invalidateQueries({ queryKey: getListRacksQueryKey() }); toast.success("Rak diperbarui"); onClose(); }, onError: () => toast.error("Gagal memperbarui rak") } });
  const [form, setForm] = useState({ name: rack?.name ?? "", location: rack?.location ?? "", description: rack?.description ?? "" });
  const isLoading = createMutation.isPending || updateMutation.isPending;
  return (
    <AnimatePresence>
      {open && (
        <div className="fixed inset-0 z-50 flex items-end md:items-center justify-center">
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="absolute inset-0 bg-black/50 backdrop-blur-sm" onClick={onClose} />
          <motion.div initial={{ scale: 0.95, opacity: 0, y: 20 }} animate={{ scale: 1, opacity: 1, y: 0 }} exit={{ scale: 0.95, opacity: 0, y: 20 }}
            className="relative bg-card border border-border rounded-t-3xl md:rounded-3xl shadow-xl w-full md:max-w-md p-6">
            <div className="flex items-center justify-between mb-5">
              <h2 className="text-base font-semibold" style={{ fontFamily: "'Outfit', sans-serif" }}>{rack ? "Edit Rak" : "Tambah Rak"}</h2>
              <button onClick={onClose} className="p-1.5 rounded-xl hover:bg-accent"><X size={16} className="text-muted-foreground" /></button>
            </div>
            <form onSubmit={e => { e.preventDefault(); const payload = { name: form.name, location: form.location || undefined, description: form.description || undefined }; if (rack) updateMutation.mutate({ id: rack.id, data: payload }); else createMutation.mutate({ data: payload }); }} className="space-y-4">
              <div>
                <label className="block text-xs font-medium text-muted-foreground mb-1.5">Nama Rak *</label>
                <input required value={form.name} onChange={e => setForm(f => ({ ...f, name: e.target.value }))} placeholder="Contoh: Rak A"
                  className="w-full px-3.5 py-2.5 bg-background border border-border rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-primary/30 focus:border-primary transition-all" />
              </div>
              <div>
                <label className="block text-xs font-medium text-muted-foreground mb-1.5">Lokasi</label>
                <input value={form.location} onChange={e => setForm(f => ({ ...f, location: e.target.value }))} placeholder="Contoh: Lantai 1 - Barat"
                  className="w-full px-3.5 py-2.5 bg-background border border-border rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-primary/30 focus:border-primary transition-all" />
              </div>
              <div>
                <label className="block text-xs font-medium text-muted-foreground mb-1.5">Deskripsi</label>
                <textarea value={form.description} onChange={e => setForm(f => ({ ...f, description: e.target.value }))} rows={2} placeholder="Deskripsi rak..."
                  className="w-full px-3.5 py-2.5 bg-background border border-border rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-primary/30 focus:border-primary resize-none transition-all" />
              </div>
              <motion.button type="submit" disabled={isLoading} whileHover={{ scale: 1.01 }} whileTap={{ scale: 0.98 }}
                className="w-full py-3 bg-primary text-primary-foreground rounded-2xl text-sm font-semibold disabled:opacity-70 flex items-center justify-center gap-2">
                {isLoading ? <><Loader2 size={14} className="animate-spin" /> Menyimpan...</> : (rack ? "Simpan Perubahan" : "Tambah Rak")}
              </motion.button>
            </form>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
}

export default function RacksPage() {
  const qc = useQueryClient();
  const [modalOpen, setModalOpen] = useState(false);
  const [editRack, setEditRack] = useState<Rack | undefined>();
  const { data: racks, isLoading } = useListRacks();
  const deleteMutation = useDeleteRack({ mutation: { onSuccess: () => { qc.invalidateQueries({ queryKey: getListRacksQueryKey() }); toast.success("Rak dihapus"); }, onError: () => toast.error("Gagal menghapus rak") } });
  return (
    <Layout>
      <div className="p-4 md:p-6 max-w-3xl mx-auto">
        <motion.div initial={{ opacity: 0, y: -8 }} animate={{ opacity: 1, y: 0 }} className="mb-5">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-xl font-bold text-foreground" style={{ fontFamily: "'Outfit', sans-serif" }}>Rak Buku</h1>
              <p className="text-sm text-muted-foreground">{(racks ?? []).length} rak terdaftar</p>
            </div>
            <motion.button whileHover={{ scale: 1.02 }} whileTap={{ scale: 0.98 }} onClick={() => { setEditRack(undefined); setModalOpen(true); }}
              className="flex items-center gap-1.5 px-4 py-2 bg-primary text-primary-foreground rounded-xl text-sm font-semibold shadow-sm">
              <Plus size={15} /> Tambah
            </motion.button>
          </div>
        </motion.div>
        {isLoading ? <div className="space-y-3">{[...Array(5)].map((_, i) => <div key={i} className="bg-card border border-border rounded-2xl h-20 animate-pulse" />)}</div>
          : (racks ?? []).length === 0 ? (
            <div className="flex flex-col items-center py-16"><BookMarked size={48} className="text-muted-foreground/30 mb-3" /><p className="text-sm text-muted-foreground">Belum ada rak</p></div>
          ) : (
            <div className="space-y-3">
              {(racks ?? []).map((rack, i) => (
                <motion.div key={rack.id} initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.04 }}
                  className="bg-card border border-border rounded-2xl p-4 shadow-sm flex items-center gap-3">
                  <div className="w-10 h-10 rounded-2xl bg-primary/10 flex items-center justify-center flex-shrink-0">
                    <BookMarked size={16} className="text-primary" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-semibold text-foreground">{rack.name}</p>
                    {rack.location && <div className="flex items-center gap-1 mt-0.5"><MapPin size={10} className="text-muted-foreground" /><p className="text-xs text-muted-foreground">{rack.location}</p></div>}
                    <p className="text-xs text-muted-foreground mt-0.5">{rack.bookCount} buku</p>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <button onClick={() => { setEditRack(rack); setModalOpen(true); }} className="w-8 h-8 rounded-xl bg-muted flex items-center justify-center hover:bg-accent transition-colors">
                      <Edit2 size={13} className="text-muted-foreground" />
                    </button>
                    <button onClick={() => { if (confirm(`Hapus rak "${rack.name}"?`)) deleteMutation.mutate({ id: rack.id }); }}
                      className="w-8 h-8 rounded-xl bg-muted flex items-center justify-center hover:bg-destructive hover:text-destructive-foreground transition-colors">
                      <Trash2 size={13} className="text-muted-foreground" />
                    </button>
                  </div>
                </motion.div>
              ))}
            </div>
          )}
      </div>
      <RackModal open={modalOpen} onClose={() => setModalOpen(false)} rack={editRack} />
    </Layout>
  );
}
