import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Plus, Search, ArrowLeftRight, X, Loader2, RotateCcw } from "lucide-react";
import { useListBorrowings, useCreateBorrowing, useReturnBook, useListMembers, useListBooks, getListBorrowingsQueryKey } from "@workspace/api-client-react";
import type { Borrowing } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import Layout from "@/components/layout";
import { formatDate, formatCurrency } from "@/lib/format";
import { cn } from "@/lib/utils";

function StatusBadge({ status }: { status: string }) {
  const styles = {
    borrowed: "bg-blue-100 text-blue-700 dark:bg-blue-900/30 dark:text-blue-400",
    returned: "bg-emerald-100 text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-400",
    overdue: "bg-red-100 text-red-700 dark:bg-red-900/30 dark:text-red-400",
  };
  const labels = { borrowed: "Dipinjam", returned: "Dikembalikan", overdue: "Terlambat" };
  return (
    <span className={cn("inline-flex px-2 py-0.5 rounded-full text-[10px] font-semibold", styles[status as keyof typeof styles] ?? "bg-muted text-muted-foreground")}>
      {labels[status as keyof typeof labels] ?? status}
    </span>
  );
}

function BorrowModal({ open, onClose }: { open: boolean; onClose: () => void }) {
  const qc = useQueryClient();
  const { data: membersData } = useListMembers({});
  const { data: booksData } = useListBooks({ status: "available", limit: 100 });
  const createMutation = useCreateBorrowing({
    mutation: {
      onSuccess: () => { qc.invalidateQueries({ queryKey: getListBorrowingsQueryKey() }); toast.success("Peminjaman berhasil dibuat"); onClose(); },
      onError: (err: unknown) => { const msg = (err as { response?: { data?: { error?: string } } })?.response?.data?.error ?? "Gagal membuat peminjaman"; toast.error(msg); }
    }
  });
  const today = new Date().toISOString().split("T")[0];
  const defaultDue = new Date(Date.now() + 14 * 86400000).toISOString().split("T")[0];
  const [form, setForm] = useState({ memberId: "", bookId: "", dueDate: defaultDue, notes: "" });
  function set(k: string, v: string) { setForm(f => ({ ...f, [k]: v })); }

  return (
    <AnimatePresence>
      {open && (
        <div className="fixed inset-0 z-50 flex items-end md:items-center justify-center">
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="absolute inset-0 bg-black/50 backdrop-blur-sm" onClick={onClose} />
          <motion.div initial={{ scale: 0.95, opacity: 0, y: 20 }} animate={{ scale: 1, opacity: 1, y: 0 }} exit={{ scale: 0.95, opacity: 0, y: 20 }}
            className="relative bg-card border border-border rounded-t-3xl md:rounded-3xl shadow-xl w-full md:max-w-md p-6 md:p-7">
            <div className="flex items-center justify-between mb-5">
              <h2 className="text-base font-semibold" style={{ fontFamily: "'Outfit', sans-serif" }}>Pinjam Buku</h2>
              <button onClick={onClose} className="p-1.5 rounded-xl hover:bg-accent"><X size={16} className="text-muted-foreground" /></button>
            </div>
            <form onSubmit={e => { e.preventDefault(); createMutation.mutate({ data: { memberId: parseInt(form.memberId), bookId: parseInt(form.bookId), dueDate: form.dueDate, notes: form.notes || undefined } }); }} className="space-y-4">
              <div>
                <label className="block text-xs font-medium text-muted-foreground mb-1.5">Anggota *</label>
                <select required value={form.memberId} onChange={e => set("memberId", e.target.value)}
                  className="w-full px-3.5 py-2.5 bg-background border border-border rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-primary/30 focus:border-primary transition-all">
                  <option value="">Pilih anggota</option>
                  {(membersData?.data ?? []).map(m => <option key={m.id} value={m.id}>{m.name} ({m.memberNumber})</option>)}
                </select>
              </div>
              <div>
                <label className="block text-xs font-medium text-muted-foreground mb-1.5">Buku *</label>
                <select required value={form.bookId} onChange={e => set("bookId", e.target.value)}
                  className="w-full px-3.5 py-2.5 bg-background border border-border rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-primary/30 focus:border-primary transition-all">
                  <option value="">Pilih buku</option>
                  {(booksData?.data ?? []).map(b => <option key={b.id} value={b.id}>{b.title} ({b.stock} tersedia)</option>)}
                </select>
              </div>
              <div>
                <label className="block text-xs font-medium text-muted-foreground mb-1.5">Batas Pengembalian *</label>
                <input type="date" required value={form.dueDate} min={today} onChange={e => set("dueDate", e.target.value)}
                  className="w-full px-3.5 py-2.5 bg-background border border-border rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-primary/30 focus:border-primary transition-all" />
              </div>
              <div>
                <label className="block text-xs font-medium text-muted-foreground mb-1.5">Catatan</label>
                <textarea value={form.notes} onChange={e => set("notes", e.target.value)} rows={2} placeholder="Catatan opsional..."
                  className="w-full px-3.5 py-2.5 bg-background border border-border rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-primary/30 focus:border-primary transition-all resize-none" />
              </div>
              <motion.button type="submit" disabled={createMutation.isPending} whileHover={{ scale: 1.01 }} whileTap={{ scale: 0.98 }}
                className="w-full py-3 bg-primary text-primary-foreground rounded-2xl text-sm font-semibold disabled:opacity-70 flex items-center justify-center gap-2">
                {createMutation.isPending ? <><Loader2 size={14} className="animate-spin" /> Memproses...</> : "Pinjam Buku"}
              </motion.button>
            </form>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
}

export default function BorrowingsPage() {
  const qc = useQueryClient();
  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState("");
  const [page, setPage] = useState(1);
  const [modalOpen, setModalOpen] = useState(false);

  const params = { search: search || undefined, status: statusFilter as "borrowed" | "returned" | "overdue" | undefined || undefined, page, limit: 15 };
  const { data: rawData, isLoading } = useListBorrowings(params, { query: { queryKey: getListBorrowingsQueryKey(params) } });
  const data = rawData as unknown as { data: Borrowing[]; total: number } | undefined;
  const returnMutation = useReturnBook({
    mutation: {
      onSuccess: (res) => { qc.invalidateQueries({ queryKey: getListBorrowingsQueryKey() }); toast.success(`Buku dikembalikan${(res.fine ?? 0) > 0 ? `. Denda: ${formatCurrency(res.fine ?? 0)}` : ""}`); },
      onError: () => toast.error("Gagal mengembalikan buku"),
    }
  });

  return (
    <Layout>
      <div className="p-4 md:p-6 max-w-5xl mx-auto">
        <motion.div initial={{ opacity: 0, y: -8 }} animate={{ opacity: 1, y: 0 }} className="mb-5">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-xl font-bold text-foreground" style={{ fontFamily: "'Outfit', sans-serif" }}>Peminjaman</h1>
              <p className="text-sm text-muted-foreground">{data?.total ?? 0} total peminjaman</p>
            </div>
            <motion.button whileHover={{ scale: 1.02 }} whileTap={{ scale: 0.98 }} onClick={() => setModalOpen(true)}
              data-testid="button-add-borrowing"
              className="flex items-center gap-1.5 px-4 py-2 bg-primary text-primary-foreground rounded-xl text-sm font-semibold shadow-sm">
              <Plus size={15} /> Pinjam
            </motion.button>
          </div>
        </motion.div>

        {/* Filters */}
        <div className="flex gap-2 mb-5 flex-wrap">
          <div className="relative flex-1 min-w-48">
            <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
            <input value={search} onChange={e => { setSearch(e.target.value); setPage(1); }} placeholder="Cari anggota atau buku..."
              className="w-full pl-9 pr-3 py-2.5 bg-card border border-border rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-primary/30 focus:border-primary transition-all" />
          </div>
          <div className="flex gap-2">
            {[{ v: "", l: "Semua" }, { v: "borrowed", l: "Dipinjam" }, { v: "returned", l: "Dikembalikan" }, { v: "overdue", l: "Terlambat" }].map(s => (
              <button key={s.v} onClick={() => { setStatusFilter(s.v); setPage(1); }}
                className={cn("px-3 py-2 rounded-xl text-xs font-medium transition-colors border",
                  statusFilter === s.v ? "bg-primary text-primary-foreground border-primary" : "bg-card border-border text-muted-foreground hover:bg-accent")}>
                {s.l}
              </button>
            ))}
          </div>
        </div>

        {/* Table / Cards */}
        {isLoading ? (
          <div className="space-y-3">{[...Array(5)].map((_, i) => <div key={i} className="bg-card border border-border rounded-2xl h-20 animate-pulse" />)}</div>
        ) : (data?.data ?? []).length === 0 ? (
          <div className="flex flex-col items-center justify-center py-16">
            <ArrowLeftRight size={48} className="text-muted-foreground/30 mb-3" />
            <p className="text-sm font-medium text-muted-foreground">Tidak ada peminjaman ditemukan</p>
          </div>
        ) : (
          <>
            {/* Desktop Table */}
            <div className="hidden md:block bg-card border border-border rounded-2xl overflow-hidden shadow-sm">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b border-border bg-muted/30">
                    {["Kode", "Anggota", "Buku", "Pinjam", "Batas", "Status", "Denda", "Aksi"].map(h => (
                      <th key={h} className="text-left px-4 py-3 text-xs font-semibold text-muted-foreground">{h}</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {(data?.data ?? []).map((b, i) => (
                    <motion.tr key={b.id} data-testid={`row-borrowing-${b.id}`}
                      initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: i * 0.03 }}
                      className="border-b border-border last:border-0 hover:bg-muted/20 transition-colors">
                      <td className="px-4 py-3 font-mono text-xs text-muted-foreground">#{b.id}</td>
                      <td className="px-4 py-3">
                        <p className="font-medium text-foreground text-xs">{b.memberName}</p>
                        <p className="text-[10px] text-muted-foreground">{b.memberNumber}</p>
                      </td>
                      <td className="px-4 py-3">
                        <p className="font-medium text-foreground text-xs line-clamp-1 max-w-40">{b.bookTitle}</p>
                        <p className="text-[10px] text-muted-foreground">{b.bookIsbn}</p>
                      </td>
                      <td className="px-4 py-3 text-xs text-muted-foreground">{formatDate(b.borrowDate)}</td>
                      <td className="px-4 py-3 text-xs text-muted-foreground">{formatDate(b.dueDate)}</td>
                      <td className="px-4 py-3"><StatusBadge status={b.status} /></td>
                      <td className="px-4 py-3 text-xs font-medium text-foreground">{(b.fine ?? 0) > 0 ? formatCurrency(b.fine ?? 0) : "-"}</td>
                      <td className="px-4 py-3">
                        {b.status !== "returned" && (
                          <motion.button whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}
                            onClick={() => { if (confirm(`Kembalikan buku "${b.bookTitle}"?`)) returnMutation.mutate({ id: b.id }); }}
                            disabled={returnMutation.isPending}
                            className="flex items-center gap-1 px-2.5 py-1.5 bg-primary/10 text-primary rounded-lg text-xs font-medium hover:bg-primary hover:text-primary-foreground transition-colors">
                            <RotateCcw size={11} /> Kembalikan
                          </motion.button>
                        )}
                      </td>
                    </motion.tr>
                  ))}
                </tbody>
              </table>
            </div>

            {/* Mobile Cards */}
            <div className="md:hidden space-y-3">
              {(data?.data ?? []).map((b, i) => (
                <motion.div key={b.id} initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.04 }}
                  className="bg-card border border-border rounded-2xl p-4 shadow-sm">
                  <div className="flex items-start justify-between mb-2">
                    <div>
                      <p className="text-xs font-semibold text-foreground">{b.memberName}</p>
                      <p className="text-[10px] text-muted-foreground">{b.memberNumber}</p>
                    </div>
                    <StatusBadge status={b.status} />
                  </div>
                  <p className="text-xs text-foreground font-medium line-clamp-1 mb-2">{b.bookTitle}</p>
                  <div className="flex items-center justify-between text-[10px] text-muted-foreground">
                    <span>Batas: {formatDate(b.dueDate)}</span>
                    {(b.fine ?? 0) > 0 && <span className="text-red-600 font-medium">{formatCurrency(b.fine ?? 0)}</span>}
                  </div>
                  {b.status !== "returned" && (
                    <button onClick={() => { if (confirm(`Kembalikan "${b.bookTitle}"?`)) returnMutation.mutate({ id: b.id }); }}
                      className="mt-3 w-full py-2 bg-primary/10 text-primary rounded-xl text-xs font-medium hover:bg-primary hover:text-primary-foreground transition-colors flex items-center justify-center gap-1.5">
                      <RotateCcw size={11} /> Kembalikan Buku
                    </button>
                  )}
                </motion.div>
              ))}
            </div>
          </>
        )}

        {/* Pagination */}
        {(data?.total ?? 0) > 15 && (
          <div className="flex justify-center gap-2 mt-6">
            <button disabled={page === 1} onClick={() => setPage(p => p - 1)} className="px-4 py-2 rounded-xl text-sm font-medium border border-border bg-card hover:bg-accent disabled:opacity-40 transition-colors">Sebelumnya</button>
            <span className="px-4 py-2 text-sm text-muted-foreground">Halaman {page}</span>
            <button disabled={(data?.data.length ?? 0) < 15} onClick={() => setPage(p => p + 1)} className="px-4 py-2 rounded-xl text-sm font-medium border border-border bg-card hover:bg-accent disabled:opacity-40 transition-colors">Berikutnya</button>
          </div>
        )}
      </div>
      <BorrowModal open={modalOpen} onClose={() => setModalOpen(false)} />
    </Layout>
  );
}
