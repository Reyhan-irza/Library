import { useState } from "react";
import { motion } from "framer-motion";
import { User, Mail, Shield, Key, Moon, Sun, LogOut, Loader2, ChevronRight } from "lucide-react";
import { useGetMe, useChangePassword, useLogout, getGetMeQueryKey } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { useLocation, Link } from "wouter";
import Layout from "@/components/layout";
import { clearToken } from "@/lib/auth";
import { useTheme } from "@/components/theme-provider";
import { cn } from "@/lib/utils";

export default function ProfilePage() {
  const [, setLocation] = useLocation();
  const qc = useQueryClient();
  const { theme, toggleTheme } = useTheme();
  const { data: user, isLoading } = useGetMe({ query: { queryKey: getGetMeQueryKey() } });
  const logoutMutation = useLogout({ mutation: { onSuccess: () => { clearToken(); qc.clear(); setLocation("/login"); } } });
  const changePasswordMutation = useChangePassword({ mutation: { onSuccess: () => { toast.success("Password berhasil diubah"); setPwForm({ old: "", new1: "", new2: "" }); setShowPw(false); }, onError: () => toast.error("Password lama salah") } });

  const [showPw, setShowPw] = useState(false);
  const [pwForm, setPwForm] = useState({ old: "", new1: "", new2: "" });

  function handleChangePassword(e: React.FormEvent) {
    e.preventDefault();
    if (pwForm.new1 !== pwForm.new2) { toast.error("Password baru tidak cocok"); return; }
    if (pwForm.new1.length < 6) { toast.error("Password minimal 6 karakter"); return; }
    changePasswordMutation.mutate({ data: { currentPassword: pwForm.old, newPassword: pwForm.new1 } });
  }

  function handleLogout() {
    if (!confirm("Yakin ingin keluar?")) return;
    logoutMutation.mutate();
  }

  const menuItems = [
    { label: "Anggota", path: "/members", desc: "Kelola data anggota perpustakaan" },
    { label: "Kategori Buku", path: "/categories", desc: "Kelola kategori koleksi buku" },
    { label: "Rak Buku", path: "/racks", desc: "Kelola rak penyimpanan buku" },
    { label: "Manajemen Petugas", path: "/staff", desc: "Kelola akun petugas perpustakaan" },
  ];

  return (
    <Layout>
      <div className="p-4 md:p-6 max-w-lg mx-auto">
        <motion.div initial={{ opacity: 0, y: -8 }} animate={{ opacity: 1, y: 0 }} className="mb-5">
          <h1 className="text-xl font-bold text-foreground" style={{ fontFamily: "'Outfit', sans-serif" }}>Profil</h1>
          <p className="text-sm text-muted-foreground">Pengaturan akun dan preferensi</p>
        </motion.div>

        {/* Profile Card */}
        <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.05 }}
          className="bg-card border border-border rounded-2xl p-6 shadow-sm mb-4">
          {isLoading ? (
            <div className="flex items-center gap-4"><div className="w-16 h-16 rounded-2xl bg-muted animate-pulse" /><div className="flex-1 space-y-2"><div className="h-4 bg-muted rounded-lg animate-pulse w-32" /><div className="h-3 bg-muted rounded-lg animate-pulse w-48" /></div></div>
          ) : (
            <div className="flex items-center gap-4">
              <div className="w-16 h-16 rounded-2xl bg-primary/10 flex items-center justify-center flex-shrink-0">
                <span className="text-2xl font-bold text-primary" style={{ fontFamily: "'Outfit', sans-serif" }}>{user?.name?.charAt(0)}</span>
              </div>
              <div className="flex-1 min-w-0">
                <h2 className="text-base font-semibold text-foreground" style={{ fontFamily: "'Outfit', sans-serif" }}>{user?.name}</h2>
                <p className="text-sm text-muted-foreground">{user?.username}</p>
                <span className={cn("inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-semibold mt-1",
                  user?.role === "admin" ? "bg-primary/10 text-primary" : "bg-sky-100 text-sky-700 dark:bg-sky-900/20 dark:text-sky-400")}>
                  {user?.role === "admin" ? "Administrator" : "Pustakawan"}
                </span>
              </div>
            </div>
          )}
          {user?.email && (
            <div className="flex items-center gap-2 mt-4 pt-4 border-t border-border">
              <Mail size={14} className="text-muted-foreground" />
              <span className="text-sm text-muted-foreground">{user.email}</span>
            </div>
          )}
        </motion.div>

        {/* Settings */}
        <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }}
          className="bg-card border border-border rounded-2xl shadow-sm mb-4 overflow-hidden">
          <div className="flex items-center justify-between px-5 py-4 border-b border-border">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-xl bg-muted flex items-center justify-center">
                {theme === "dark" ? <Moon size={14} className="text-muted-foreground" /> : <Sun size={14} className="text-muted-foreground" />}
              </div>
              <div>
                <p className="text-sm font-medium text-foreground">Mode Gelap</p>
                <p className="text-xs text-muted-foreground">{theme === "dark" ? "Aktif" : "Nonaktif"}</p>
              </div>
            </div>
            <button data-testid="toggle-dark-mode" onClick={toggleTheme}
              className={cn("w-11 h-6 rounded-full transition-all duration-300 relative flex-shrink-0", theme === "dark" ? "bg-primary" : "bg-muted")}>
              <motion.div animate={{ x: theme === "dark" ? 20 : 2 }} transition={{ type: "spring", stiffness: 500, damping: 35 }}
                className="w-5 h-5 rounded-full bg-white shadow absolute top-0.5" />
            </button>
          </div>
          <button onClick={() => setShowPw(v => !v)}
            className="w-full flex items-center justify-between px-5 py-4 hover:bg-accent transition-colors">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-xl bg-muted flex items-center justify-center">
                <Key size={14} className="text-muted-foreground" />
              </div>
              <p className="text-sm font-medium text-foreground">Ubah Password</p>
            </div>
            <ChevronRight size={16} className={cn("text-muted-foreground transition-transform", showPw && "rotate-90")} />
          </button>
          {showPw && (
            <motion.div initial={{ height: 0, opacity: 0 }} animate={{ height: "auto", opacity: 1 }} className="overflow-hidden border-t border-border">
              <form onSubmit={handleChangePassword} className="p-5 space-y-3">
                {[
                  { label: "Password Lama", key: "old" as const },
                  { label: "Password Baru", key: "new1" as const },
                  { label: "Konfirmasi Password Baru", key: "new2" as const },
                ].map(f => (
                  <div key={f.key}>
                    <label className="block text-xs font-medium text-muted-foreground mb-1">{f.label}</label>
                    <input type="password" required value={pwForm[f.key]} onChange={e => setPwForm(p => ({ ...p, [f.key]: e.target.value }))}
                      className="w-full px-3.5 py-2.5 bg-background border border-border rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-primary/30 focus:border-primary transition-all" />
                  </div>
                ))}
                <motion.button type="submit" disabled={changePasswordMutation.isPending} whileHover={{ scale: 1.01 }} whileTap={{ scale: 0.98 }}
                  className="w-full py-2.5 bg-primary text-primary-foreground rounded-xl text-sm font-semibold disabled:opacity-70 flex items-center justify-center gap-2">
                  {changePasswordMutation.isPending ? <><Loader2 size={14} className="animate-spin" /> Menyimpan...</> : "Simpan Password"}
                </motion.button>
              </form>
            </motion.div>
          )}
        </motion.div>

        {/* Management Links */}
        <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.15 }}
          className="bg-card border border-border rounded-2xl shadow-sm mb-4 overflow-hidden">
          <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wider px-5 pt-4 pb-2">Manajemen</p>
          {menuItems.map((item, i) => (
            <Link key={item.path} href={item.path}>
              <div className={cn("flex items-center justify-between px-5 py-3.5 hover:bg-accent transition-colors cursor-pointer", i < menuItems.length - 1 && "border-b border-border")}>
                <div>
                  <p className="text-sm font-medium text-foreground">{item.label}</p>
                  <p className="text-xs text-muted-foreground">{item.desc}</p>
                </div>
                <ChevronRight size={15} className="text-muted-foreground" />
              </div>
            </Link>
          ))}
        </motion.div>

        {/* Logout */}
        <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }}>
          <motion.button whileHover={{ scale: 1.02 }} whileTap={{ scale: 0.98 }} onClick={handleLogout}
            data-testid="button-logout"
            className="w-full py-3 bg-destructive/10 text-destructive rounded-2xl text-sm font-semibold hover:bg-destructive hover:text-destructive-foreground transition-colors flex items-center justify-center gap-2">
            <LogOut size={15} /> Keluar dari Akun
          </motion.button>
        </motion.div>
      </div>
    </Layout>
  );
}
