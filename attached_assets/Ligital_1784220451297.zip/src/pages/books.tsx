import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Plus, Search, BookOpen, Trash2, Edit2, ScanBarcode, X, Loader2, Heart, Filter, ChevronDown } from "lucide-react";
import {
  useListBooks, useCreateBook, useUpdateBook, useDeleteBook,
  useListCategories, useListRacks,
  useGetFavoriteIds, useAddFavorite, useRemoveFavorite,
  getListBooksQueryKey, getGetFavoritesQueryKey, getGetFavoriteIdsQueryKey,
} from "@workspace/api-client-react";
import type { Book, BookInput, BookUpdate } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import Layout from "@/components/layout";
import { cn } from "@/lib/utils";
import BookDetailSheet from "@/components/book-detail-sheet";

function StatusBadge({ status }: { status: string }) {
  return (
    <span className={cn(
      "inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-semibold",
      status === "available"
        ? "bg-emerald-100 text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-400"
        : "bg-amber-100 text-amber-700 dark:bg-amber-900/30 dark:text-amber-400",
    )}>
      {status === "available" ? "Tersedia" : "Dipinjam"}
    </span>
  );
}

function BookModal({ open, onClose, book }: { open: boolean; onClose: () => void; book?: Book }) {
  const qc = useQueryClient();
  const { data: categories } = useListCategories();
  const { data: racks } = useListRacks();
  const createMutation = useCreateBook({ mutation: { onSuccess: () => { qc.invalidateQueries({ queryKey: getListBooksQueryKey() }); toast.success("Buku berhasil ditambahkan"); onClose(); }, onError: () => toast.error("Gagal menambahkan buku") } });
  const updateMutation = useUpdateBook({ mutation: { onSuccess: () => { qc.invalidateQueries({ queryKey: getListBooksQueryKey() }); toast.success("Buku berhasil diperbarui"); onClose(); }, onError: () => toast.error("Gagal memperbarui buku") } });

  const [form, setForm] = useState({
    isbn: book?.isbn ?? "", title: book?.title ?? "", author: book?.author ?? "",
    publisher: book?.publisher ?? "", year: book?.year?.toString() ?? "",
    stock: book?.stock?.toString() ?? "1", description: book?.description ?? "",
    pages: book?.pages?.toString() ?? "",
    categoryId: book?.categoryId?.toString() ?? "", rackId: book?.rackId?.toString() ?? "",
    coverUrl: book?.coverUrl ?? "",
  });

  function set(k: string, v: string) { setForm(f => ({ ...f, [k]: v })); }

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    const payload = {
      isbn: form.isbn, title: form.title, author: form.author,
      publisher: form.publisher || undefined, year: form.year ? parseInt(form.year) : undefined,
      stock: parseInt(form.stock) || 1, description: form.description || undefined,
      pages: form.pages ? parseInt(form.pages) : undefined,
      categoryId: form.categoryId ? parseInt(form.categoryId) : undefined,
      rackId: form.rackId ? parseInt(form.rackId) : undefined,
      coverUrl: form.coverUrl || undefined,
    };
    if (book) updateMutation.mutate({ id: book.id, data: payload as BookUpdate });
    else createMutation.mutate({ data: payload as BookInput });
  }

  const isLoading = createMutation.isPending || updateMutation.isPending;

  return (
    <AnimatePresence>
      {open && (
        <div className="fixed inset-0 z-50 flex items-end md:items-center justify-center p-0 md:p-4">
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="absolute inset-0 bg-black/50 backdrop-blur-sm" onClick={onClose} />
          <motion.div
            initial={{ y: "100%", opacity: 0 }} animate={{ y: 0, opacity: 1 }} exit={{ y: "100%", opacity: 0 }}
            transition={{ type: "spring", stiffness: 340, damping: 34 }}
            className="relative bg-card border border-border rounded-t-[28px] md:rounded-[28px] shadow-xl w-full md:max-w-lg max-h-[90vh] overflow-y-auto"
          >
            <div className="sticky top-0 bg-card border-b border-border px-6 py-4 flex items-center justify-between rounded-t-[28px]">
              <h2 className="text-base font-semibold text-foreground" style={{ fontFamily: "'Outfit', sans-serif" }}>{book ? "Edit Buku" : "Tambah Buku"}</h2>
              <button onClick={onClose} className="p-1.5 rounded-xl hover:bg-accent"><X size={16} className="text-muted-foreground" /></button>
            </div>
            <form onSubmit={handleSubmit} className="p-6 space-y-4">
              {[
                { label: "ISBN", key: "isbn", placeholder: "978-xxx-xxx-xxx", required: true },
                { label: "Judul Buku", key: "title", placeholder: "Masukkan judul", required: true },
                { label: "Penulis", key: "author", placeholder: "Nama penulis", required: true },
                { label: "Penerbit", key: "publisher", placeholder: "Nama penerbit" },
                { label: "URL Cover", key: "coverUrl", placeholder: "https://..." },
              ].map(f => (
                <div key={f.key}>
                  <label className="block text-xs font-medium text-muted-foreground mb-1">{f.label}{f.required && " *"}</label>
                  <input value={(form as Record<string, string>)[f.key]} onChange={e => set(f.key, e.target.value)} required={f.required}
                    placeholder={f.placeholder}
                    className="w-full px-3.5 py-2.5 bg-background border border-border rounded-xl text-sm focus:outline-none transition-all" />
                </div>
              ))}
              <div className="grid grid-cols-3 gap-3">
                <div>
                  <label className="block text-xs font-medium text-muted-foreground mb-1">Tahun</label>
                  <input type="number" value={form.year} onChange={e => set("year", e.target.value)} placeholder="2024"
                    className="w-full px-3.5 py-2.5 bg-background border border-border rounded-xl text-sm focus:outline-none transition-all" />
                </div>
                <div>
                  <label className="block text-xs font-medium text-muted-foreground mb-1">Stok *</label>
                  <input type="number" value={form.stock} onChange={e => set("stock", e.target.value)} required min="1"
                    className="w-full px-3.5 py-2.5 bg-background border border-border rounded-xl text-sm focus:outline-none transition-all" />
                </div>
                <div>
                  <label className="block text-xs font-medium text-muted-foreground mb-1">Halaman</label>
                  <input type="number" value={form.pages} onChange={e => set("pages", e.target.value)} placeholder="250"
                    className="w-full px-3.5 py-2.5 bg-background border border-border rounded-xl text-sm focus:outline-none transition-all" />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-medium text-muted-foreground mb-1">Kategori</label>
                  <select value={form.categoryId} onChange={e => set("categoryId", e.target.value)}
                    className="w-full px-3.5 py-2.5 bg-background border border-border rounded-xl text-sm focus:outline-none transition-all">
                    <option value="">Pilih kategori</option>
                    {(categories ?? []).map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-medium text-muted-foreground mb-1">Rak</label>
                  <select value={form.rackId} onChange={e => set("rackId", e.target.value)}
                    className="w-full px-3.5 py-2.5 bg-background border border-border rounded-xl text-sm focus:outline-none transition-all">
                    <option value="">Pilih rak</option>
                    {(racks ?? []).map(r => <option key={r.id} value={r.id}>{r.name}</option>)}
                  </select>
                </div>
              </div>
              <div>
                <label className="block text-xs font-medium text-muted-foreground mb-1">Sinopsis / Deskripsi</label>
                <textarea value={form.description} onChange={e => set("description", e.target.value)} rows={3} placeholder="Deskripsi singkat buku..."
                  className="w-full px-3.5 py-2.5 bg-background border border-border rounded-xl text-sm focus:outline-none transition-all resize-none" />
              </div>
              <motion.button type="submit" disabled={isLoading} whileHover={{ scale: 1.01 }} whileTap={{ scale: 0.98 }}
                className="w-full py-3 bg-primary text-primary-foreground rounded-2xl text-sm font-semibold disabled:opacity-70 flex items-center justify-center gap-2 shadow-sm shadow-primary/20">
                {isLoading ? <><Loader2 size={14} className="animate-spin" /> Menyimpan...</> : (book ? "Simpan Perubahan" : "Tambah Buku")}
              </motion.button>
            </form>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
}

export default function BooksPage() {
  const qc = useQueryClient();
  const [search, setSearch] = useState("");
  const [categoryFilter, setCategoryFilter] = useState("");
  const [statusFilter, setStatusFilter] = useState("");
  const [page, setPage] = useState(1);
  const [modalOpen, setModalOpen] = useState(false);
  const [editBook, setEditBook] = useState<Book | undefined>();
  const [barcodeModal, setBarcodeModal] = useState(false);
  const [scannedIsbn, setScannedIsbn] = useState("");
  const [selectedBook, setSelectedBook] = useState<Book | null>(null);
  const [sheetOpen, setSheetOpen] = useState(false);
  const [showFilters, setShowFilters] = useState(false);

  const params = {
    search: search || undefined,
    categoryId: categoryFilter ? parseInt(categoryFilter) : undefined,
    status: statusFilter as "available" | "borrowed" | undefined || undefined,
    page,
    limit: 12,
  };
  const { data, isLoading } = useListBooks(params, { query: { queryKey: getListBooksQueryKey(params) } });
  const { data: categories } = useListCategories();
  const { data: favoriteIds = [] } = useGetFavoriteIds({ query: { queryKey: getGetFavoriteIdsQueryKey() } });

  const deleteMutation = useDeleteBook({ mutation: { onSuccess: () => { qc.invalidateQueries({ queryKey: getListBooksQueryKey() }); toast.success("Buku dihapus"); }, onError: () => toast.error("Gagal menghapus buku") } });
  const addFavMutation = useAddFavorite({ mutation: { onSuccess: () => { qc.invalidateQueries({ queryKey: [getGetFavoritesQueryKey(), getGetFavoriteIdsQueryKey()] }); toast.success("Ditambahkan ke favorit"); }, onError: () => toast.error("Gagal") } });
  const removeFavMutation = useRemoveFavorite({ mutation: { onSuccess: () => { qc.invalidateQueries({ queryKey: [getGetFavoritesQueryKey(), getGetFavoriteIdsQueryKey()] }); toast.success("Dihapus dari favorit"); }, onError: () => toast.error("Gagal") } });

  function openAdd() { setEditBook(undefined); setModalOpen(true); }
  function openEdit(b: Book) { setEditBook(b); setModalOpen(true); }
  function openDetail(b: Book) { setSelectedBook(b); setSheetOpen(true); }

  function handleDelete(b: Book) {
    if (!confirm(`Hapus buku "${b.title}"?`)) return;
    deleteMutation.mutate({ id: b.id });
  }

  function handleToggleFavorite(book: Book) {
    const isFav = (favoriteIds as number[]).includes(book.id);
    if (isFav) removeFavMutation.mutate({ bookId: book.id });
    else addFavMutation.mutate({ data: { bookId: book.id } });
  }

  const activeFilters = [categoryFilter, statusFilter].filter(Boolean).length;

  return (
    <Layout>
      <div className="p-4 md:p-6 max-w-5xl mx-auto">

        {/* Header */}
        <motion.div initial={{ opacity: 0, y: -8 }} animate={{ opacity: 1, y: 0 }} className="mb-5">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-xl font-bold text-foreground" style={{ fontFamily: "'Outfit', sans-serif" }}>Koleksi Buku</h1>
              <p className="text-sm text-muted-foreground">{data?.total ?? 0} buku terdaftar</p>
            </div>
            <div className="flex gap-2">
              <motion.button whileHover={{ scale: 1.02 }} whileTap={{ scale: 0.98 }} onClick={() => setBarcodeModal(true)}
                className="flex items-center gap-1.5 px-3 py-2 bg-muted text-muted-foreground rounded-xl text-sm font-medium hover:bg-accent transition-colors">
                <ScanBarcode size={15} /> <span className="hidden sm:block">Scan</span>
              </motion.button>
              <motion.button whileHover={{ scale: 1.02 }} whileTap={{ scale: 0.98 }} onClick={openAdd}
                data-testid="button-add-book"
                className="flex items-center gap-1.5 px-4 py-2 bg-primary text-primary-foreground rounded-xl text-sm font-semibold shadow-sm shadow-primary/20">
                <Plus size={15} /> Tambah
              </motion.button>
            </div>
          </div>
        </motion.div>

        {/* Search + Filter row */}
        <div className="flex gap-2 mb-3">
          <div className="relative flex-1">
            <Search size={14} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-muted-foreground pointer-events-none" />
            <input value={search} onChange={e => { setSearch(e.target.value); setPage(1); }} placeholder="Cari judul, penulis..."
              className="w-full pl-10 pr-3 py-2.5 bg-card border border-border rounded-xl text-sm focus:outline-none transition-all" />
          </div>
          <motion.button
            whileTap={{ scale: 0.95 }}
            onClick={() => setShowFilters(v => !v)}
            className={cn(
              "flex items-center gap-1.5 px-3.5 py-2.5 rounded-xl text-sm font-medium border transition-all duration-200",
              showFilters || activeFilters > 0
                ? "bg-primary/10 text-primary border-primary/30"
                : "bg-card border-border text-muted-foreground hover:bg-accent",
            )}
          >
            <Filter size={13} />
            <span className="hidden sm:block">Filter</span>
            {activeFilters > 0 && (
              <span className="w-4 h-4 rounded-full bg-primary text-primary-foreground text-[9px] flex items-center justify-center font-bold">
                {activeFilters}
              </span>
            )}
            <ChevronDown size={12} className={cn("transition-transform duration-200", showFilters && "rotate-180")} />
          </motion.button>
        </div>

        {/* Collapsible filters */}
        <AnimatePresence>
          {showFilters && (
            <motion.div
              initial={{ height: 0, opacity: 0 }}
              animate={{ height: "auto", opacity: 1 }}
              exit={{ height: 0, opacity: 0 }}
              transition={{ duration: 0.2 }}
              className="overflow-hidden mb-4"
            >
              <div className="flex flex-wrap gap-2 py-1">
                <select value={categoryFilter} onChange={e => { setCategoryFilter(e.target.value); setPage(1); }}
                  className="px-3.5 py-2.5 bg-card border border-border rounded-xl text-sm focus:outline-none transition-all flex-1 min-w-36">
                  <option value="">Semua Kategori</option>
                  {(categories ?? []).map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
                </select>
                <div className="flex gap-1">
                  {["", "available", "borrowed"].map(s => (
                    <button key={s} onClick={() => { setStatusFilter(s); setPage(1); }}
                      className={cn(
                        "px-3 py-2 rounded-xl text-xs font-medium transition-all duration-200",
                        statusFilter === s ? "bg-primary text-primary-foreground" : "bg-card border border-border text-muted-foreground hover:bg-accent",
                      )}>
                      {s === "" ? "Semua" : s === "available" ? "Tersedia" : "Dipinjam"}
                    </button>
                  ))}
                </div>
                {activeFilters > 0 && (
                  <button onClick={() => { setCategoryFilter(""); setStatusFilter(""); setPage(1); }}
                    className="px-3 py-2 rounded-xl text-xs font-medium text-destructive hover:bg-destructive/10 transition-colors">
                    Reset
                  </button>
                )}
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Book Grid */}
        {isLoading ? (
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3">
            {[...Array(8)].map((_, i) => (
              <div key={i} className="bg-card border border-border rounded-2xl overflow-hidden">
                <div className="aspect-[3/4] bg-muted animate-pulse" />
                <div className="p-3 space-y-2">
                  <div className="h-3 bg-muted rounded animate-pulse" />
                  <div className="h-2 bg-muted rounded w-2/3 animate-pulse" />
                </div>
              </div>
            ))}
          </div>
        ) : (data?.data ?? []).length === 0 ? (
          <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }}
            className="flex flex-col items-center justify-center py-20 text-center">
            <div className="w-20 h-20 rounded-3xl bg-muted flex items-center justify-center mb-4">
              <BookOpen size={36} className="text-muted-foreground/30" />
            </div>
            <h3 className="text-base font-semibold text-foreground mb-1" style={{ fontFamily: "'Outfit', sans-serif" }}>
              Tidak Ada Buku
            </h3>
            <p className="text-sm text-muted-foreground mb-4">
              {search || categoryFilter || statusFilter
                ? "Tidak ada buku yang sesuai dengan filter"
                : "Belum ada buku terdaftar"}
            </p>
            {(search || categoryFilter || statusFilter) && (
              <button onClick={() => { setSearch(""); setCategoryFilter(""); setStatusFilter(""); }}
                className="px-4 py-2 bg-primary text-primary-foreground rounded-xl text-sm font-medium">
                Reset Filter
              </button>
            )}
          </motion.div>
        ) : (
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3">
            {(data?.data ?? []).map((book, i) => {
              const isFav = (favoriteIds as number[]).includes(book.id);
              return (
                <motion.div key={book.id} data-testid={`card-book-${book.id}`}
                  initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.04 }}
                  whileHover={{ y: -4, transition: { duration: 0.2 } }}
                  onClick={() => openDetail(book)}
                  className="bg-card border border-border rounded-2xl overflow-hidden shadow-card group cursor-pointer transition-shadow hover:shadow-md"
                >
                  <div className="aspect-[3/4] bg-muted relative overflow-hidden">
                    {book.coverUrl ? (
                      <img src={book.coverUrl} alt={book.title} className="w-full h-full object-cover" loading="lazy" />
                    ) : (
                      <div className="w-full h-full flex items-center justify-center bg-gradient-to-br from-primary/10 to-primary/5">
                        <BookOpen size={32} className="text-primary/30" />
                      </div>
                    )}
                    <div className="absolute top-2 left-2"><StatusBadge status={book.status} /></div>
                    <div className="absolute inset-0 bg-black/0 group-hover:bg-black/10 transition-colors duration-200" />

                    {/* Action buttons on hover */}
                    <div className="absolute bottom-2 right-2 flex gap-1 opacity-0 group-hover:opacity-100 transition-all duration-200">
                      <motion.button
                        whileTap={{ scale: 0.85 }}
                        onClick={e => { e.stopPropagation(); handleToggleFavorite(book); }}
                        className={cn(
                          "w-7 h-7 rounded-lg flex items-center justify-center shadow-sm transition-colors",
                          isFav ? "bg-rose-500 text-white" : "bg-card text-muted-foreground hover:bg-rose-500/10 hover:text-rose-500",
                        )}
                      >
                        <Heart size={11} fill={isFav ? "currentColor" : "none"} />
                      </motion.button>
                      <motion.button
                        whileTap={{ scale: 0.85 }}
                        onClick={e => { e.stopPropagation(); openEdit(book); }}
                        className="w-7 h-7 bg-card rounded-lg flex items-center justify-center shadow-sm hover:bg-accent transition-colors"
                      >
                        <Edit2 size={11} className="text-foreground" />
                      </motion.button>
                      <motion.button
                        whileTap={{ scale: 0.85 }}
                        onClick={e => { e.stopPropagation(); handleDelete(book); }}
                        className="w-7 h-7 bg-card rounded-lg flex items-center justify-center shadow-sm hover:bg-destructive hover:text-destructive-foreground transition-colors"
                      >
                        <Trash2 size={11} className="text-foreground" />
                      </motion.button>
                    </div>
                  </div>
                  <div className="p-3">
                    <p className="text-xs font-semibold text-foreground line-clamp-2 leading-tight">{book.title}</p>
                    <p className="text-[10px] text-muted-foreground mt-1 line-clamp-1">{book.author}</p>
                    {book.categoryName && <p className="text-[10px] text-primary/70 mt-1">{book.categoryName}</p>}
                    <p className="text-[10px] text-muted-foreground mt-1">{book.stock} eks. tersedia</p>
                  </div>
                </motion.div>
              );
            })}
          </div>
        )}

        {/* Pagination */}
        {(data?.total ?? 0) > 12 && (
          <div className="flex justify-center gap-2 mt-6">
            <button disabled={page === 1} onClick={() => setPage(p => p - 1)}
              className="px-4 py-2 rounded-xl text-sm font-medium border border-border bg-card hover:bg-accent disabled:opacity-40 transition-colors">
              Sebelumnya
            </button>
            <span className="px-4 py-2 text-sm text-muted-foreground">Hal. {page} / {Math.ceil((data?.total ?? 0) / 12)}</span>
            <button disabled={(data?.data.length ?? 0) < 12} onClick={() => setPage(p => p + 1)}
              className="px-4 py-2 rounded-xl text-sm font-medium border border-border bg-card hover:bg-accent disabled:opacity-40 transition-colors">
              Berikutnya
            </button>
          </div>
        )}
      </div>

      <BookModal open={modalOpen} onClose={() => setModalOpen(false)} book={editBook} />

      <BookDetailSheet
        book={selectedBook}
        open={sheetOpen}
        onClose={() => setSheetOpen(false)}
        isFavorite={(favoriteIds as number[]).includes(selectedBook?.id ?? -1)}
        onToggleFavorite={handleToggleFavorite}
      />

      {/* Barcode Modal */}
      <AnimatePresence>
        {barcodeModal && (
          <div className="fixed inset-0 z-50 flex items-end md:items-center justify-center p-0 md:p-4">
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="absolute inset-0 bg-black/50 backdrop-blur-sm" onClick={() => setBarcodeModal(false)} />
            <motion.div initial={{ y: "100%", opacity: 0 }} animate={{ y: 0, opacity: 1 }} exit={{ y: "100%", opacity: 0 }}
              transition={{ type: "spring", stiffness: 340, damping: 34 }}
              className="relative bg-card border border-border rounded-t-[28px] md:rounded-[28px] shadow-xl w-full md:max-w-sm p-6">
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-base font-semibold" style={{ fontFamily: "'Outfit', sans-serif" }}>Scan Barcode ISBN</h2>
                <button onClick={() => setBarcodeModal(false)} className="p-1.5 rounded-xl hover:bg-accent"><X size={16} className="text-muted-foreground" /></button>
              </div>
              <div className="bg-muted rounded-2xl p-8 flex flex-col items-center gap-3 mb-4">
                <ScanBarcode size={48} className="text-primary/40" />
                <p className="text-xs text-muted-foreground text-center">Arahkan kamera ke barcode ISBN buku</p>
              </div>
              <div>
                <label className="block text-xs font-medium text-muted-foreground mb-1.5">Atau masukkan ISBN manual</label>
                <div className="flex gap-2">
                  <input value={scannedIsbn} onChange={e => setScannedIsbn(e.target.value)} placeholder="978-xxx-xxx-xxx"
                    className="flex-1 px-3.5 py-2.5 bg-background border border-border rounded-xl text-sm focus:outline-none" />
                  <button onClick={() => { setBarcodeModal(false); setSearch(scannedIsbn); setScannedIsbn(""); }}
                    className="px-4 py-2.5 bg-primary text-primary-foreground rounded-xl text-sm font-medium">Cari</button>
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </Layout>
  );
}
