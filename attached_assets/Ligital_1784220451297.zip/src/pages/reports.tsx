import { useState } from "react";
import { motion } from "framer-motion";
import { BarChart3, Download, FileSpreadsheet, TrendingUp, TrendingDown, BookOpen, Users } from "lucide-react";
import { useGetReportSummary, getGetReportSummaryQueryKey } from "@workspace/api-client-react";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts";
import Layout from "@/components/layout";
import { formatCurrency } from "@/lib/format";
import { toast } from "sonner";
import { cn } from "@/lib/utils";

export default function ReportsPage() {
  const [startDate, setStartDate] = useState("");
  const [endDate, setEndDate] = useState("");
  const params = { startDate: startDate || undefined, endDate: endDate || undefined };
  const { data, isLoading } = useGetReportSummary(params, { query: { queryKey: getGetReportSummaryQueryKey(params) } });

  const chartData = [
    { name: "Total", value: data?.totalBorrowings ?? 0, fill: "#1F5E4A" },
    { name: "Kembali", value: data?.totalReturned ?? 0, fill: "#34d399" },
    { name: "Terlambat", value: data?.totalOverdue ?? 0, fill: "#f59e0b" },
  ];

  function handleExport(type: "pdf" | "excel") {
    toast.success(`Laporan ${type === "pdf" ? "PDF" : "Excel"} sedang disiapkan...`);
    setTimeout(() => toast.success(`Laporan ${type === "pdf" ? "PDF" : "Excel"} berhasil diunduh`), 1500);
  }

  return (
    <Layout>
      <div className="p-4 md:p-6 max-w-5xl mx-auto">
        <motion.div initial={{ opacity: 0, y: -8 }} animate={{ opacity: 1, y: 0 }} className="mb-5">
          <div className="flex items-center justify-between flex-wrap gap-3">
            <div>
              <h1 className="text-xl font-bold text-foreground" style={{ fontFamily: "'Outfit', sans-serif" }}>Laporan</h1>
              <p className="text-sm text-muted-foreground">Ringkasan statistik perpustakaan</p>
            </div>
            <div className="flex gap-2">
              <motion.button whileHover={{ scale: 1.02 }} whileTap={{ scale: 0.98 }} onClick={() => handleExport("pdf")}
                data-testid="button-export-pdf"
                className="flex items-center gap-1.5 px-3.5 py-2 border border-border bg-card rounded-xl text-sm font-medium hover:bg-accent transition-colors">
                <Download size={14} /> PDF
              </motion.button>
              <motion.button whileHover={{ scale: 1.02 }} whileTap={{ scale: 0.98 }} onClick={() => handleExport("excel")}
                data-testid="button-export-excel"
                className="flex items-center gap-1.5 px-3.5 py-2 border border-border bg-card rounded-xl text-sm font-medium hover:bg-accent transition-colors">
                <FileSpreadsheet size={14} /> Excel
              </motion.button>
            </div>
          </div>

          {/* Date Filter */}
          <div className="flex gap-2 mt-4 flex-wrap">
            <div className="flex items-center gap-2">
              <label className="text-xs text-muted-foreground font-medium">Dari:</label>
              <input type="date" value={startDate} onChange={e => setStartDate(e.target.value)}
                className="px-3 py-2 bg-card border border-border rounded-xl text-xs focus:outline-none focus:ring-2 focus:ring-primary/30 focus:border-primary transition-all" />
            </div>
            <div className="flex items-center gap-2">
              <label className="text-xs text-muted-foreground font-medium">Sampai:</label>
              <input type="date" value={endDate} onChange={e => setEndDate(e.target.value)}
                className="px-3 py-2 bg-card border border-border rounded-xl text-xs focus:outline-none focus:ring-2 focus:ring-primary/30 focus:border-primary transition-all" />
            </div>
            {(startDate || endDate) && (
              <button onClick={() => { setStartDate(""); setEndDate(""); }} className="px-3 py-2 text-xs text-muted-foreground hover:text-foreground border border-border bg-card rounded-xl transition-colors">Reset</button>
            )}
          </div>
        </motion.div>

        {isLoading ? (
          <div className="grid grid-cols-2 md:grid-cols-3 gap-3 mb-6">{[...Array(5)].map((_, i) => <div key={i} className="bg-card border border-border rounded-2xl h-28 animate-pulse" />)}</div>
        ) : (
          <>
            {/* Summary Cards */}
            <div className="grid grid-cols-2 md:grid-cols-3 gap-3 mb-6">
              {[
                { label: "Total Peminjaman", value: data?.totalBorrowings ?? 0, icon: BarChart3, color: "bg-primary/10 text-primary" },
                { label: "Dikembalikan", value: data?.totalReturned ?? 0, icon: TrendingUp, color: "bg-emerald-100 text-emerald-700 dark:bg-emerald-900/20 dark:text-emerald-400" },
                { label: "Terlambat", value: data?.totalOverdue ?? 0, icon: TrendingDown, color: "bg-amber-100 text-amber-700 dark:bg-amber-900/20 dark:text-amber-400" },
                { label: "Total Denda", value: data?.totalFine ?? 0, icon: FileSpreadsheet, color: "bg-sky-100 text-sky-700 dark:bg-sky-900/20 dark:text-sky-400", isCurrency: true },
              ].map((item, i) => (
                <motion.div key={item.label} initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.06 }}
                  className="bg-card border border-border rounded-2xl p-5 shadow-sm">
                  <div className={cn("w-9 h-9 rounded-xl flex items-center justify-center mb-3", item.color)}>
                    <item.icon size={16} />
                  </div>
                  <p className="text-xl font-bold text-foreground" style={{ fontFamily: "'Outfit', sans-serif" }}>
                    {item.isCurrency ? formatCurrency(item.value) : item.value.toLocaleString("id-ID")}
                  </p>
                  <p className="text-xs text-muted-foreground mt-1">{item.label}</p>
                </motion.div>
              ))}
            </div>

            {/* Chart */}
            <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.3 }}
              className="bg-card border border-border rounded-2xl p-5 shadow-sm mb-6">
              <h3 className="text-sm font-semibold text-foreground mb-4" style={{ fontFamily: "'Outfit', sans-serif" }}>Ringkasan Peminjaman</h3>
              <ResponsiveContainer width="100%" height={200}>
                <BarChart data={chartData} margin={{ top: 4, right: 4, bottom: 0, left: -20 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" vertical={false} />
                  <XAxis dataKey="name" tick={{ fontSize: 11, fill: "hsl(var(--muted-foreground))" }} axisLine={false} tickLine={false} />
                  <YAxis tick={{ fontSize: 11, fill: "hsl(var(--muted-foreground))" }} axisLine={false} tickLine={false} />
                  <Tooltip contentStyle={{ background: "hsl(var(--card))", border: "1px solid hsl(var(--border))", borderRadius: "12px", fontSize: 12 }} />
                  <Bar dataKey="value" fill="#1F5E4A" radius={[8, 8, 0, 0]} animationDuration={800} />
                </BarChart>
              </ResponsiveContainer>
            </motion.div>

            <div className="grid md:grid-cols-2 gap-4">
              {/* Total Members */}
              <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.35 }}
                className="bg-card border border-border rounded-2xl p-5 shadow-sm">
                <div className="flex items-center gap-2 mb-4">
                  <Users size={16} className="text-primary" />
                  <h3 className="text-sm font-semibold text-foreground" style={{ fontFamily: "'Outfit', sans-serif" }}>Statistik Anggota</h3>
                </div>
                <div className="space-y-3">
                  <div className="flex items-center justify-between py-2 border-b border-border">
                    <span className="text-xs text-muted-foreground">Total Anggota</span>
                    <span className="text-sm font-bold text-foreground">{data?.totalMembers ?? 0}</span>
                  </div>
                  <div className="flex items-center justify-between py-2">
                    <span className="text-xs text-muted-foreground">Total Buku</span>
                    <span className="text-sm font-bold text-foreground">{data?.totalBooks ?? 0}</span>
                  </div>
                </div>
              </motion.div>

              {/* Borrowing Summary */}
              <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.4 }}
                className="bg-card border border-border rounded-2xl p-5 shadow-sm">
                <div className="flex items-center gap-2 mb-4">
                  <BookOpen size={16} className="text-primary" />
                  <h3 className="text-sm font-semibold text-foreground" style={{ fontFamily: "'Outfit', sans-serif" }}>Ringkasan Status</h3>
                </div>
                <div className="space-y-3">
                  <div className="flex items-center justify-between py-2 border-b border-border">
                    <span className="text-xs text-muted-foreground">Dikembalikan</span>
                    <span className="text-sm font-bold text-emerald-600">{data?.totalReturned ?? 0}</span>
                  </div>
                  <div className="flex items-center justify-between py-2">
                    <span className="text-xs text-muted-foreground">Terlambat</span>
                    <span className="text-sm font-bold text-red-500">{data?.totalOverdue ?? 0}</span>
                  </div>
                </div>
              </motion.div>
            </div>
          </>
        )}
      </div>
    </Layout>
  );
}
