import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Plus, Settings, X, Loader2, Trash2, Edit2 } from "lucide-react";
import { useListStaff, useCreateStaff, useUpdateStaff, useDeleteStaff, getListStaffQueryKey } from "@workspace/api-client-react";
import type { StaffMember } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import Layout from "@/components/layout";
import { cn } from "@/lib/utils";

function StaffModal({ open, onClose, staff }: { open: boolean; onClose: () => void; staff?: StaffMember }) {
  const qc = useQueryClient();
  const createMutation = useCreateStaff({ mutation: { onSuccess: () => { qc.invalidateQueries({ queryKey: getListStaffQueryKey() }); toast.success("Petugas ditambahkan"); onClose(); }, onError: () => toast.error("Gagal menambahkan petugas") } });
  const updateMutation = useUpdateStaff({ mutation: { onSuccess: () => { qc.invalidateQueries({ queryKey: getListStaffQueryKey() }); toast.success("Petugas diperbarui"); onClose(); }, onError: () => toast.error("Gagal memperbarui petugas") } });
  const [form, setForm] = useState<{ username: string; password: string; name: string; email: string; role: "admin" | "librarian" }>({ username: staff?.username ?? "", password: "", name: staff?.name ?? "", email: staff?.email ?? "", role: (staff?.role as "admin" | "librarian") ?? "librarian" });
  const isLoading = createMutation.isPending || updateMutation.isPending;
  return (
    <AnimatePresence>
      {open && (
        <div className="fixed inset-0 z-50 flex items-end md:items-center justify-center">
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="absolute inset-0 bg-black/50 backdrop-blur-sm" onClick={onClose} />
          <motion.div initial={{ scale: 0.95, opacity: 0, y: 20 }} animate={{ scale: 1, opacity: 1, y: 0 }} exit={{ scale: 0.95, opacity: 0, y: 20 }}
            className="relative bg-card border border-border rounded-t-3xl md:rounded-3xl shadow-xl w-full md:max-w-md max-h-[90vh] overflow-y-auto p-6">
            <div className="flex items-center justify-between mb-5">
              <h2 className="text-base font-semibold" style={{ fontFamily: "'Outfit', sans-serif" }}>{staff ? "Edit Petugas" : "Tambah Petugas"}</h2>
              <button onClick={onClose} className="p-1.5 rounded-xl hover:bg-accent"><X size={16} className="text-muted-foreground" /></button>
            </div>
            <form onSubmit={e => {
              e.preventDefault();
              if (staff) updateMutation.mutate({ id: staff.id, data: { name: form.name, email: form.email || undefined, role: form.role as "admin" | "librarian" } });
              else createMutation.mutate({ data: { username: form.username, password: form.password, name: form.name, email: form.email || undefined, role: form.role as "admin" | "librarian" } });
            }} className="space-y-4">
              {!staff && (
                <>
                  <div>
                    <label className="block text-xs font-medium text-muted-foreground mb-1.5">Username *</label>
                    <input required value={form.username} onChange={e => setForm(f => ({ ...f, username: e.target.value }))} placeholder="Username unik..."
                      className="w-full px-3.5 py-2.5 bg-background border border-border rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-primary/30 focus:border-primary transition-all" />
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-muted-foreground mb-1.5">Password *</label>
                    <input type="password" required value={form.password} onChange={e => setForm(f => ({ ...f, password: e.target.value }))} placeholder="Password..."
                      className="w-full px-3.5 py-2.5 bg-background border border-border rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-primary/30 focus:border-primary transition-all" />
                  </div>
                </>
              )}
              <div>
                <label className="block text-xs font-medium text-muted-foreground mb-1.5">Nama Lengkap *</label>
                <input required value={form.name} onChange={e => setForm(f => ({ ...f, name: e.target.value }))} placeholder="Nama petugas..."
                  className="w-full px-3.5 py-2.5 bg-background border border-border rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-primary/30 focus:border-primary transition-all" />
              </div>
              <div>
                <label className="block text-xs font-medium text-muted-foreground mb-1.5">Email</label>
                <input type="email" value={form.email} onChange={e => setForm(f => ({ ...f, email: e.target.value }))} placeholder="Email petugas..."
                  className="w-full px-3.5 py-2.5 bg-background border border-border rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-primary/30 focus:border-primary transition-all" />
              </div>
              <div>
                <label className="block text-xs font-medium text-muted-foreground mb-1.5">Role</label>
                <select value={form.role} onChange={e => setForm(f => ({ ...f, role: e.target.value as "admin" | "librarian" }))}
                  className="w-full px-3.5 py-2.5 bg-background border border-border rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-primary/30 focus:border-primary transition-all">
                  <option value="librarian">Pustakawan</option>
                  <option value="admin">Administrator</option>
                </select>
              </div>
              <motion.button type="submit" disabled={isLoading} whileHover={{ scale: 1.01 }} whileTap={{ scale: 0.98 }}
                className="w-full py-3 bg-primary text-primary-foreground rounded-2xl text-sm font-semibold disabled:opacity-70 flex items-center justify-center gap-2">
                {isLoading ? <><Loader2 size={14} className="animate-spin" /> Menyimpan...</> : (staff ? "Simpan Perubahan" : "Tambah Petugas")}
              </motion.button>
            </form>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
}

export default function StaffPage() {
  const qc = useQueryClient();
  const [modalOpen, setModalOpen] = useState(false);
  const [editStaff, setEditStaff] = useState<StaffMember | undefined>();
  const { data: staffList, isLoading } = useListStaff();
  const deleteMutation = useDeleteStaff({ mutation: { onSuccess: () => { qc.invalidateQueries({ queryKey: getListStaffQueryKey() }); toast.success("Petugas dihapus"); }, onError: () => toast.error("Gagal menghapus petugas") } });
  return (
    <Layout>
      <div className="p-4 md:p-6 max-w-3xl mx-auto">
        <motion.div initial={{ opacity: 0, y: -8 }} animate={{ opacity: 1, y: 0 }} className="mb-5">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-xl font-bold text-foreground" style={{ fontFamily: "'Outfit', sans-serif" }}>Petugas</h1>
              <p className="text-sm text-muted-foreground">{(staffList ?? []).length} petugas terdaftar</p>
            </div>
            <motion.button whileHover={{ scale: 1.02 }} whileTap={{ scale: 0.98 }} onClick={() => { setEditStaff(undefined); setModalOpen(true); }}
              className="flex items-center gap-1.5 px-4 py-2 bg-primary text-primary-foreground rounded-xl text-sm font-semibold shadow-sm">
              <Plus size={15} /> Tambah
            </motion.button>
          </div>
        </motion.div>
        {isLoading ? <div className="space-y-3">{[...Array(3)].map((_, i) => <div key={i} className="bg-card border border-border rounded-2xl h-20 animate-pulse" />)}</div>
          : (staffList ?? []).length === 0 ? (
            <div className="flex flex-col items-center py-16"><Settings size={48} className="text-muted-foreground/30 mb-3" /><p className="text-sm text-muted-foreground">Belum ada petugas</p></div>
          ) : (
            <div className="space-y-3">
              {(staffList ?? []).map((s, i) => (
                <motion.div key={s.id} initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.04 }}
                  className="bg-card border border-border rounded-2xl p-4 shadow-sm flex items-center gap-3">
                  <div className="w-10 h-10 rounded-2xl bg-primary/10 flex items-center justify-center flex-shrink-0">
                    <span className="text-sm font-bold text-primary">{s.name.charAt(0)}</span>
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2">
                      <p className="text-sm font-semibold text-foreground">{s.name}</p>
                      <span className={cn("text-[10px] px-1.5 py-0.5 rounded-md font-semibold", s.role === "admin" ? "bg-primary/10 text-primary" : "bg-sky-100 text-sky-700 dark:bg-sky-900/20 dark:text-sky-400")}>
                        {s.role === "admin" ? "Admin" : "Pustakawan"}
                      </span>
                    </div>
                    <p className="text-xs text-muted-foreground">@{s.username}</p>
                    {s.email && <p className="text-xs text-muted-foreground">{s.email}</p>}
                  </div>
                  <div className="flex items-center gap-1.5">
                    <button onClick={() => { setEditStaff(s); setModalOpen(true); }} className="w-8 h-8 rounded-xl bg-muted flex items-center justify-center hover:bg-accent transition-colors">
                      <Edit2 size={13} className="text-muted-foreground" />
                    </button>
                    <button onClick={() => { if (confirm(`Hapus petugas "${s.name}"?`)) deleteMutation.mutate({ id: s.id }); }}
                      className="w-8 h-8 rounded-xl bg-muted flex items-center justify-center hover:bg-destructive hover:text-destructive-foreground transition-colors">
                      <Trash2 size={13} className="text-muted-foreground" />
                    </button>
                  </div>
                </motion.div>
              ))}
            </div>
          )}
      </div>
      <StaffModal open={modalOpen} onClose={() => setModalOpen(false)} staff={editStaff} />
    </Layout>
  );
}
