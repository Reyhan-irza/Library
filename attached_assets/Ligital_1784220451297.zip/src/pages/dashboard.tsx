import { useEffect, useRef, useState } from "react";
import { motion } from "framer-motion";
import {
  BookOpen, Users, ArrowLeftRight, BookCheck, AlertTriangle,
  TrendingUp, Bell, Sun, Moon, Search, ChevronRight,
  ArrowUpRight, ArrowDownLeft, Sparkles, Pencil, Trash2, Pin,
  Trophy, Medal, Crown, Layers,
} from "lucide-react";
import {
  useGetDashboardStats,
  useGetDashboardChart,
  useGetRecentActivities,
  useGetTopBooks,
  useGetNotifications,
  useListCategories,
} from "@workspace/api-client-react";
import {
  AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
  BarChart, Bar, Cell,
} from "recharts";
import Layout from "@/components/layout";
import { formatCurrency, formatDateTime } from "@/lib/format";
import { useTheme } from "@/components/theme-provider";
import { Link } from "wouter";
import { cn } from "@/lib/utils";
import { getUser } from "@/lib/auth";

function useCountUp(target: number, duration = 1000) {
  const [count, setCount] = useState(0);
  useEffect(() => {
    if (target === 0) { setCount(0); return; }
    const startTime = performance.now();
    function update(now: number) {
      const progress = Math.min((now - startTime) / duration, 1);
      const eased = 1 - Math.pow(1 - progress, 3);
      setCount(Math.round(eased * target));
      if (progress < 1) requestAnimationFrame(update);
    }
    const raf = requestAnimationFrame(update);
    return () => cancelAnimationFrame(raf);
  }, [target, duration]);
  return count;
}

function useInView() {
  const ref = useRef<HTMLDivElement>(null);
  const [inView, setInView] = useState(false);
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const observer = new IntersectionObserver(
      ([entry]) => { if (entry.isIntersecting) { setInView(true); observer.disconnect(); } },
      { threshold: 0.1 },
    );
    observer.observe(el);
    return () => observer.disconnect();
  }, []);
  return { ref, inView };
}

const statConfigs = [
  { key: "totalBooks",     title: "Total Buku",    icon: BookOpen,       bg: "from-primary to-primary/80",       shadow: "shadow-primary/25",  glow: "card-glow-green" },
  { key: "totalMembers",   title: "Total Anggota", icon: Users,          bg: "from-sky-500 to-sky-400",           shadow: "shadow-sky-500/25",  glow: "card-glow-blue" },
  { key: "totalBorrowed",  title: "Dipinjam",      icon: ArrowLeftRight, bg: "from-amber-500 to-amber-400",      shadow: "shadow-amber-500/25", glow: "card-glow-amber" },
  { key: "totalAvailable", title: "Tersedia",      icon: BookCheck,      bg: "from-emerald-500 to-emerald-400",  shadow: "shadow-emerald-500/25", glow: "card-glow-emerald" },
  { key: "overdueCount",   title: "Terlambat",     icon: AlertTriangle,  bg: "from-rose-500 to-rose-400",        shadow: "shadow-rose-500/25",  glow: "card-glow-rose" },
  { key: "totalFine",      title: "Total Denda",   icon: TrendingUp,     bg: "from-violet-500 to-violet-400",    shadow: "shadow-violet-500/25", isCurrency: true },
] as const;

function StatCard({ title, value, icon: Icon, bg, shadow, glow, isCurrency, delay }: {
  title: string; value: number; icon: React.ElementType;
  bg: string; shadow: string; glow?: string; isCurrency?: boolean; delay: number;
}) {
  const count = useCountUp(value);
  const { ref, inView } = useInView();

  return (
    <motion.div
      ref={ref}
      initial={{ opacity: 0, y: 20 }}
      animate={inView ? { opacity: 1, y: 0 } : {}}
      transition={{ delay, duration: 0.45, ease: [0.23, 1, 0.32, 1] }}
      whileHover={{ y: -4, transition: { duration: 0.2 } }}
      className={cn("bg-card border border-border rounded-[20px] p-5 shadow-card cursor-default group transition-all duration-300", glow)}
    >
      <div className={cn("w-10 h-10 rounded-xl flex items-center justify-center mb-4 shadow-lg bg-gradient-to-br", bg, shadow)}>
        <Icon size={18} className="text-white" />
      </div>
      <p className="text-2xl font-bold text-foreground leading-none">
        {isCurrency ? formatCurrency(count) : count.toLocaleString("id-ID")}
      </p>
      <p className="text-xs text-muted-foreground mt-1.5 font-medium">{title}</p>
    </motion.div>
  );
}

const activityIconMap: Record<string, React.ElementType> = {
  borrow: ArrowUpRight, return: ArrowDownLeft,
  create: Sparkles, update: Pencil, delete: Trash2,
};
const activityColorMap: Record<string, string> = {
  borrow: "bg-amber-500/10 text-amber-500",
  return: "bg-emerald-500/10 text-emerald-500",
  create: "bg-primary/10 text-primary",
  update: "bg-sky-500/10 text-sky-500",
  delete: "bg-rose-500/10 text-rose-500",
};

const RANK_ICONS = [Crown, Trophy, Medal];
const RANK_COLORS = ["text-amber-400", "text-slate-400", "text-orange-400"];

const CATEGORY_COLORS = [
  "hsl(161 50% 35%)", "hsl(199 89% 48%)", "hsl(270 60% 60%)",
  "hsl(35 91% 55%)", "hsl(340 82% 52%)", "hsl(175 84% 35%)",
  "hsl(220 70% 60%)", "hsl(150 60% 45%)",
];

export default function DashboardPage() {
  const { data: stats, isLoading: statsLoading } = useGetDashboardStats();
  const { data: chart } = useGetDashboardChart();
  const { data: activities } = useGetRecentActivities();
  const { data: topBooks } = useGetTopBooks({ limit: 5 });
  const { data: notifData } = useGetNotifications();
  const { data: categoriesRaw } = useListCategories();
  const { theme, toggleTheme } = useTheme();

  const user = getUser();
  const hour = new Date().getHours();
  const greeting = hour < 12 ? "Selamat Pagi" : hour < 17 ? "Selamat Siang" : "Selamat Malam";
  const displayName = user?.name || user?.username || "Admin";

  const unreadCount = notifData?.unreadCount ?? 0;

  const categoryChartData = (Array.isArray(categoriesRaw) ? categoriesRaw : [])
    .filter((c: { bookCount?: number | null }) => (c.bookCount ?? 0) > 0)
    .slice(0, 7)
    .map((c: { name: string; bookCount?: number | null }) => ({ name: c.name.length > 10 ? c.name.slice(0, 10) + "…" : c.name, value: c.bookCount ?? 0 }));

  const { ref: statsRef, inView: statsInView } = useInView();
  const { ref: chartRef, inView: chartInView } = useInView();
  const { ref: topBooksRef, inView: topBooksInView } = useInView();

  return (
    <Layout>
      <div className="p-4 md:p-6 max-w-5xl mx-auto">

        {/* ── Header ── */}
        <motion.div initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }} className="mb-6">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-xl font-bold text-foreground">
                {greeting},{" "}
                <span className="gradient-text">{displayName}</span>
              </h1>
              <p className="text-sm text-muted-foreground mt-0.5">
                {new Date().toLocaleDateString("id-ID", { weekday: "long", day: "numeric", month: "long", year: "numeric" })}
              </p>
            </div>
            <div className="flex items-center gap-2">
              <motion.button
                whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}
                onClick={toggleTheme}
                className="w-9 h-9 rounded-xl bg-muted flex items-center justify-center hover:bg-accent transition-all duration-200"
                aria-label="Toggle tema"
              >
                {theme === "dark"
                  ? <Sun size={15} className="text-muted-foreground" />
                  : <Moon size={15} className="text-muted-foreground" />}
              </motion.button>
              <div className="relative">
                <motion.button
                  whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}
                  className="w-9 h-9 rounded-xl bg-muted flex items-center justify-center hover:bg-accent transition-all duration-200 relative"
                  aria-label="Notifikasi"
                >
                  <Bell size={15} className="text-muted-foreground" />
                  {unreadCount > 0 && (
                    <motion.span
                      initial={{ scale: 0 }}
                      animate={{ scale: 1 }}
                      className="absolute -top-0.5 -right-0.5 w-4 h-4 bg-rose-500 text-white rounded-full text-[9px] flex items-center justify-center font-bold leading-none"
                    >
                      {unreadCount}
                    </motion.span>
                  )}
                </motion.button>
              </div>
            </div>
          </div>

          {/* Search */}
          <div className="mt-4 relative">
            <Search size={15} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-muted-foreground pointer-events-none" />
            <input
              data-testid="input-search"
              placeholder="Cari buku, anggota, peminjaman..."
              aria-label="Pencarian"
              className="w-full pl-10 pr-4 py-2.5 bg-card/80 border border-border rounded-[20px] text-sm text-foreground placeholder:text-muted-foreground focus:outline-none transition-all duration-200"
            />
          </div>
        </motion.div>

        {/* ── Stats ── */}
        <div ref={statsRef} className="mb-6">
          {statsLoading ? (
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3">
              {[...Array(6)].map((_, i) => (
                <div key={i} className="bg-card border border-border rounded-[20px] p-5 h-[114px] animate-pulse" />
              ))}
            </div>
          ) : (
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3">
              {statConfigs.map((s, i) => (
                <StatCard
                  key={s.key}
                  title={s.title}
                  value={(stats as unknown as Record<string, number>)?.[s.key] ?? 0}
                  icon={s.icon}
                  bg={s.bg}
                  shadow={s.shadow}
                  glow={"glow" in s ? s.glow : undefined}
                  isCurrency={"isCurrency" in s ? s.isCurrency : undefined}
                  delay={statsInView ? 0.05 + i * 0.06 : 0}
                />
              ))}
            </div>
          )}
        </div>

        {/* ── Chart + Activities ── */}
        <div ref={chartRef} className="grid grid-cols-1 lg:grid-cols-3 gap-4 mb-4">

          {/* Borrowing Area Chart */}
          <motion.div
            initial={{ opacity: 0, y: 16 }}
            animate={chartInView ? { opacity: 1, y: 0 } : {}}
            transition={{ delay: 0.1, duration: 0.45 }}
            className="lg:col-span-2 bg-card/90 border border-border rounded-[20px] p-5 shadow-card"
          >
            <div className="flex items-center justify-between mb-5">
              <div>
                <h3 className="text-sm font-semibold text-foreground">Aktivitas Peminjaman</h3>
                <p className="text-xs text-muted-foreground">6 bulan terakhir</p>
              </div>
              <div className="flex items-center gap-4 text-xs text-muted-foreground">
                <span className="flex items-center gap-1.5">
                  <span className="w-2 h-2 rounded-full bg-primary inline-block" />Dipinjam
                </span>
                <span className="flex items-center gap-1.5">
                  <span className="w-2 h-2 rounded-full bg-emerald-400 inline-block" />Dikembalikan
                </span>
              </div>
            </div>
            <ResponsiveContainer width="100%" height={190}>
              <AreaChart data={chart ?? []} margin={{ top: 4, right: 4, bottom: 0, left: -24 }}>
                <defs>
                  <linearGradient id="colorBorrowed" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="hsl(var(--primary))" stopOpacity={0.2} />
                    <stop offset="95%" stopColor="hsl(var(--primary))" stopOpacity={0} />
                  </linearGradient>
                  <linearGradient id="colorReturned" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#34d399" stopOpacity={0.2} />
                    <stop offset="95%" stopColor="#34d399" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" vertical={false} />
                <XAxis dataKey="month" tick={{ fontSize: 10, fill: "hsl(var(--muted-foreground))" }} axisLine={false} tickLine={false} />
                <YAxis tick={{ fontSize: 10, fill: "hsl(var(--muted-foreground))" }} axisLine={false} tickLine={false} />
                <Tooltip
                  contentStyle={{
                    background: "hsl(var(--card))",
                    border: "1px solid hsl(var(--border))",
                    borderRadius: "14px",
                    fontSize: 12,
                    boxShadow: "0 8px 24px rgba(0,0,0,.12)",
                  }}
                  cursor={{ stroke: "hsl(var(--border))", strokeWidth: 1 }}
                />
                <Area type="monotone" dataKey="borrowed" name="Dipinjam" stroke="hsl(var(--primary))" strokeWidth={2.5} fill="url(#colorBorrowed)" animationDuration={900} />
                <Area type="monotone" dataKey="returned" name="Dikembalikan" stroke="#34d399" strokeWidth={2.5} fill="url(#colorReturned)" animationDuration={900} />
              </AreaChart>
            </ResponsiveContainer>
          </motion.div>

          {/* Recent Activities */}
          <motion.div
            initial={{ opacity: 0, y: 16 }}
            animate={chartInView ? { opacity: 1, y: 0 } : {}}
            transition={{ delay: 0.18, duration: 0.45 }}
            className="bg-card/90 border border-border rounded-[20px] p-5 shadow-card"
          >
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-sm font-semibold text-foreground">Aktivitas Terbaru</h3>
              <Link href="/borrowings">
                <motion.button whileHover={{ x: 2 }} className="text-xs text-primary font-medium flex items-center gap-0.5 hover:opacity-80 transition-opacity">
                  Semua <ChevronRight size={11} />
                </motion.button>
              </Link>
            </div>

            <div className="space-y-3">
              {(activities ?? []).slice(0, 6).map((activity, i) => {
                const ActivityIcon = activityIconMap[activity.type] ?? Pin;
                const colorClass = activityColorMap[activity.type] ?? "bg-muted text-muted-foreground";
                return (
                  <motion.div
                    key={activity.id}
                    initial={{ opacity: 0, x: 10 }}
                    animate={chartInView ? { opacity: 1, x: 0 } : {}}
                    transition={{ delay: 0.25 + i * 0.05, duration: 0.3 }}
                    className="flex items-start gap-2.5"
                  >
                    <div className={cn("w-6 h-6 rounded-lg flex items-center justify-center flex-shrink-0 mt-0.5", colorClass)}>
                      <ActivityIcon size={11} />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-xs text-foreground line-clamp-2 leading-relaxed">{activity.description}</p>
                      <p className="text-[10px] text-muted-foreground mt-0.5">{formatDateTime(activity.createdAt)}</p>
                    </div>
                  </motion.div>
                );
              })}
              {(!activities || activities.length === 0) && (
                <div className="flex flex-col items-center py-6 text-center">
                  <div className="w-10 h-10 rounded-2xl bg-muted flex items-center justify-center mb-2">
                    <Bell size={16} className="text-muted-foreground/40" />
                  </div>
                  <p className="text-xs text-muted-foreground">Belum ada aktivitas</p>
                </div>
              )}
            </div>
          </motion.div>
        </div>

        {/* ── Top Books + Category Chart ── */}
        <div ref={topBooksRef} className="grid grid-cols-1 lg:grid-cols-2 gap-4 mb-4">

          {/* Top Borrowed Books */}
          <motion.div
            initial={{ opacity: 0, y: 16 }}
            animate={topBooksInView ? { opacity: 1, y: 0 } : {}}
            transition={{ delay: 0.05, duration: 0.45 }}
            className="bg-card/90 border border-border rounded-[20px] p-5 shadow-card"
          >
            <div className="flex items-center justify-between mb-4">
              <div>
                <h3 className="text-sm font-semibold text-foreground">Buku Terpopuler</h3>
                <p className="text-xs text-muted-foreground">Berdasarkan jumlah peminjaman</p>
              </div>
              <div className="w-8 h-8 rounded-xl bg-amber-500/10 flex items-center justify-center">
                <Trophy size={15} className="text-amber-500" />
              </div>
            </div>

            <div className="space-y-3">
              {(topBooks ?? []).slice(0, 5).map((book, i) => {
                const RankIcon = RANK_ICONS[i] ?? Medal;
                const rankColor = RANK_COLORS[i] ?? "text-muted-foreground";
                const maxBorrows = (topBooks?.[0] as { borrowCount?: number })?.borrowCount ?? 1;
                const pct = Math.round(((book as { borrowCount?: number }).borrowCount ?? 0) / maxBorrows * 100);
                return (
                  <motion.div
                    key={(book as { id?: number }).id ?? i}
                    initial={{ opacity: 0, x: -8 }}
                    animate={topBooksInView ? { opacity: 1, x: 0 } : {}}
                    transition={{ delay: 0.1 + i * 0.07, duration: 0.3 }}
                    className="flex items-center gap-3 group"
                  >
                    <div className="flex-shrink-0 w-6 flex items-center justify-center">
                      <RankIcon size={i < 3 ? 16 : 13} className={cn("transition-transform group-hover:scale-110", rankColor)} />
                    </div>
                    <div className="w-9 h-12 rounded-lg bg-muted overflow-hidden flex-shrink-0">
                      {(book as { coverUrl?: string }).coverUrl ? (
                        <img
                          src={(book as { coverUrl?: string }).coverUrl}
                          alt={(book as { title?: string }).title}
                          className="w-full h-full object-cover"
                        />
                      ) : (
                        <div className="w-full h-full flex items-center justify-center bg-gradient-to-br from-primary/10 to-primary/5">
                          <BookOpen size={12} className="text-primary/40" />
                        </div>
                      )}
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-xs font-semibold text-foreground line-clamp-1">
                        {(book as { title?: string }).title}
                      </p>
                      <p className="text-[10px] text-muted-foreground line-clamp-1">
                        {(book as { author?: string }).author}
                      </p>
                      <div className="mt-1.5 h-1 bg-muted rounded-full overflow-hidden">
                        <motion.div
                          initial={{ width: 0 }}
                          animate={topBooksInView ? { width: `${pct}%` } : {}}
                          transition={{ delay: 0.3 + i * 0.07, duration: 0.6, ease: "easeOut" }}
                          className="h-full bg-gradient-to-r from-primary to-primary/70 rounded-full"
                        />
                      </div>
                    </div>
                    <div className="flex-shrink-0 text-right">
                      <span className="text-xs font-bold text-foreground">
                        {(book as { borrowCount?: number }).borrowCount ?? 0}
                      </span>
                      <p className="text-[9px] text-muted-foreground">pinjam</p>
                    </div>
                  </motion.div>
                );
              })}
              {(!topBooks || topBooks.length === 0) && (
                <div className="flex flex-col items-center py-6 text-center">
                  <div className="w-10 h-10 rounded-2xl bg-muted flex items-center justify-center mb-2">
                    <BookOpen size={16} className="text-muted-foreground/40" />
                  </div>
                  <p className="text-xs text-muted-foreground">Belum ada data peminjaman</p>
                </div>
              )}
            </div>
          </motion.div>

          {/* Category Distribution Chart */}
          <motion.div
            initial={{ opacity: 0, y: 16 }}
            animate={topBooksInView ? { opacity: 1, y: 0 } : {}}
            transition={{ delay: 0.12, duration: 0.45 }}
            className="bg-card/90 border border-border rounded-[20px] p-5 shadow-card"
          >
            <div className="flex items-center justify-between mb-4">
              <div>
                <h3 className="text-sm font-semibold text-foreground">Koleksi per Kategori</h3>
                <p className="text-xs text-muted-foreground">Distribusi buku berdasarkan kategori</p>
              </div>
              <Link href="/categories">
                <motion.button whileHover={{ x: 2 }} className="text-xs text-primary font-medium flex items-center gap-0.5 hover:opacity-80 transition-opacity">
                  Kelola <ChevronRight size={11} />
                </motion.button>
              </Link>
            </div>

            {categoryChartData.length > 0 ? (
              <ResponsiveContainer width="100%" height={190}>
                <BarChart data={categoryChartData} layout="vertical" margin={{ top: 0, right: 16, bottom: 0, left: 0 }}>
                  <XAxis type="number" tick={{ fontSize: 10, fill: "hsl(var(--muted-foreground))" }} axisLine={false} tickLine={false} />
                  <YAxis
                    type="category"
                    dataKey="name"
                    tick={{ fontSize: 10, fill: "hsl(var(--muted-foreground))" }}
                    axisLine={false}
                    tickLine={false}
                    width={70}
                  />
                  <Tooltip
                    contentStyle={{
                      background: "hsl(var(--card))",
                      border: "1px solid hsl(var(--border))",
                      borderRadius: "12px",
                      fontSize: 12,
                      boxShadow: "0 8px 24px rgba(0,0,0,.12)",
                    }}
                    cursor={{ fill: "hsl(var(--muted)/0.4)" }}
                    formatter={(v) => [`${v} buku`, "Jumlah"]}
                  />
                  <Bar dataKey="value" radius={[0, 6, 6, 0]} animationDuration={900} animationBegin={topBooksInView ? 200 : 9999}>
                    {categoryChartData.map((_entry, index) => (
                      <Cell key={`cell-${index}`} fill={CATEGORY_COLORS[index % CATEGORY_COLORS.length]} fillOpacity={0.85} />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            ) : (
              <div className="flex flex-col items-center justify-center h-[190px] text-center">
                <div className="w-10 h-10 rounded-2xl bg-muted flex items-center justify-center mb-2">
                  <Layers size={16} className="text-muted-foreground/40" />
                </div>
                <p className="text-xs text-muted-foreground">Belum ada data kategori</p>
              </div>
            )}
          </motion.div>
        </div>

        {/* ── Quick Actions ── */}
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5 }}
        >
          <h3 className="text-sm font-semibold text-foreground mb-3">Akses Cepat</h3>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
            {[
              { label: "Tambah Buku",  path: "/books",      icon: BookOpen,      color: "bg-primary/10 text-primary",              border: "hover:border-primary/30" },
              { label: "Pinjam Buku",  path: "/borrowings", icon: ArrowLeftRight, color: "bg-amber-500/10 text-amber-600 dark:text-amber-400",  border: "hover:border-amber-500/30" },
              { label: "Anggota",      path: "/members",    icon: Users,          color: "bg-sky-500/10 text-sky-600 dark:text-sky-400",         border: "hover:border-sky-500/30" },
              { label: "Laporan",      path: "/reports",    icon: TrendingUp,     color: "bg-violet-500/10 text-violet-600 dark:text-violet-400", border: "hover:border-violet-500/30" },
            ].map((item) => (
              <Link key={item.path} href={item.path}>
                <motion.div
                  whileHover={{ y: -3, transition: { duration: 0.2 } }}
                  whileTap={{ scale: 0.97 }}
                  className={cn("bg-card/90 border border-border rounded-[20px] p-4 flex items-center gap-3 cursor-pointer hover:shadow-md transition-all duration-200", item.border)}
                >
                  <div className={cn("w-9 h-9 rounded-xl flex items-center justify-center flex-shrink-0", item.color)}>
                    <item.icon size={16} />
                  </div>
                  <span className="text-sm font-medium text-foreground leading-tight">{item.label}</span>
                </motion.div>
              </Link>
            ))}
          </div>
        </motion.div>

      </div>
    </Layout>
  );
}
