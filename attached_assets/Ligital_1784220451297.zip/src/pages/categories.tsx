import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Plus, Layers, X, Loader2, Trash2, Edit2 } from "lucide-react";
import { useListCategories, useCreateCategory, useUpdateCategory, useDeleteCategory, getListCategoriesQueryKey } from "@workspace/api-client-react";
import type { Category } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import Layout from "@/components/layout";

function CategoryModal({ open, onClose, category }: { open: boolean; onClose: () => void; category?: Category }) {
  const qc = useQueryClient();
  const createMutation = useCreateCategory({ mutation: { onSuccess: () => { qc.invalidateQueries({ queryKey: getListCategoriesQueryKey() }); toast.success("Kategori ditambahkan"); onClose(); }, onError: () => toast.error("Gagal menambahkan kategori") } });
  const updateMutation = useUpdateCategory({ mutation: { onSuccess: () => { qc.invalidateQueries({ queryKey: getListCategoriesQueryKey() }); toast.success("Kategori diperbarui"); onClose(); }, onError: () => toast.error("Gagal memperbarui kategori") } });
  const [form, setForm] = useState({ name: category?.name ?? "", description: category?.description ?? "" });
  const isLoading = createMutation.isPending || updateMutation.isPending;
  return (
    <AnimatePresence>
      {open && (
        <div className="fixed inset-0 z-50 flex items-end md:items-center justify-center">
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="absolute inset-0 bg-black/50 backdrop-blur-sm" onClick={onClose} />
          <motion.div initial={{ scale: 0.95, opacity: 0, y: 20 }} animate={{ scale: 1, opacity: 1, y: 0 }} exit={{ scale: 0.95, opacity: 0, y: 20 }}
            className="relative bg-card border border-border rounded-t-3xl md:rounded-3xl shadow-xl w-full md:max-w-md p-6">
            <div className="flex items-center justify-between mb-5">
              <h2 className="text-base font-semibold" style={{ fontFamily: "'Outfit', sans-serif" }}>{category ? "Edit Kategori" : "Tambah Kategori"}</h2>
              <button onClick={onClose} className="p-1.5 rounded-xl hover:bg-accent"><X size={16} className="text-muted-foreground" /></button>
            </div>
            <form onSubmit={e => { e.preventDefault(); const payload = { name: form.name, description: form.description || undefined }; if (category) updateMutation.mutate({ id: category.id, data: payload }); else createMutation.mutate({ data: payload }); }} className="space-y-4">
              <div>
                <label className="block text-xs font-medium text-muted-foreground mb-1.5">Nama Kategori *</label>
                <input required value={form.name} onChange={e => setForm(f => ({ ...f, name: e.target.value }))} placeholder="Nama kategori..."
                  className="w-full px-3.5 py-2.5 bg-background border border-border rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-primary/30 focus:border-primary transition-all" />
              </div>
              <div>
                <label className="block text-xs font-medium text-muted-foreground mb-1.5">Deskripsi</label>
                <textarea value={form.description} onChange={e => setForm(f => ({ ...f, description: e.target.value }))} rows={3} placeholder="Deskripsi kategori..."
                  className="w-full px-3.5 py-2.5 bg-background border border-border rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-primary/30 focus:border-primary resize-none transition-all" />
              </div>
              <motion.button type="submit" disabled={isLoading} whileHover={{ scale: 1.01 }} whileTap={{ scale: 0.98 }}
                className="w-full py-3 bg-primary text-primary-foreground rounded-2xl text-sm font-semibold disabled:opacity-70 flex items-center justify-center gap-2">
                {isLoading ? <><Loader2 size={14} className="animate-spin" /> Menyimpan...</> : (category ? "Simpan Perubahan" : "Tambah Kategori")}
              </motion.button>
            </form>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
}

export default function CategoriesPage() {
  const qc = useQueryClient();
  const [modalOpen, setModalOpen] = useState(false);
  const [editCat, setEditCat] = useState<Category | undefined>();
  const { data: categories, isLoading } = useListCategories();
  const deleteMutation = useDeleteCategory({ mutation: { onSuccess: () => { qc.invalidateQueries({ queryKey: getListCategoriesQueryKey() }); toast.success("Kategori dihapus"); }, onError: () => toast.error("Gagal menghapus kategori") } });
  return (
    <Layout>
      <div className="p-4 md:p-6 max-w-3xl mx-auto">
        <motion.div initial={{ opacity: 0, y: -8 }} animate={{ opacity: 1, y: 0 }} className="mb-5">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-xl font-bold text-foreground" style={{ fontFamily: "'Outfit', sans-serif" }}>Kategori Buku</h1>
              <p className="text-sm text-muted-foreground">{(categories ?? []).length} kategori</p>
            </div>
            <motion.button whileHover={{ scale: 1.02 }} whileTap={{ scale: 0.98 }} onClick={() => { setEditCat(undefined); setModalOpen(true); }}
              className="flex items-center gap-1.5 px-4 py-2 bg-primary text-primary-foreground rounded-xl text-sm font-semibold shadow-sm">
              <Plus size={15} /> Tambah
            </motion.button>
          </div>
        </motion.div>
        {isLoading ? <div className="space-y-3">{[...Array(5)].map((_, i) => <div key={i} className="bg-card border border-border rounded-2xl h-20 animate-pulse" />)}</div>
          : (categories ?? []).length === 0 ? (
            <div className="flex flex-col items-center py-16"><Layers size={48} className="text-muted-foreground/30 mb-3" /><p className="text-sm text-muted-foreground">Belum ada kategori</p></div>
          ) : (
            <div className="space-y-3">
              {(categories ?? []).map((cat, i) => (
                <motion.div key={cat.id} initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.04 }}
                  className="bg-card border border-border rounded-2xl p-4 shadow-sm flex items-center gap-3">
                  <div className="w-10 h-10 rounded-2xl bg-primary/10 flex items-center justify-center flex-shrink-0">
                    <Layers size={16} className="text-primary" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-semibold text-foreground">{cat.name}</p>
                    {cat.description && <p className="text-xs text-muted-foreground mt-0.5 line-clamp-1">{cat.description}</p>}
                    <p className="text-xs text-muted-foreground mt-0.5">{cat.bookCount} buku</p>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <button onClick={() => { setEditCat(cat); setModalOpen(true); }} className="w-8 h-8 rounded-xl bg-muted flex items-center justify-center hover:bg-accent transition-colors">
                      <Edit2 size={13} className="text-muted-foreground" />
                    </button>
                    <button onClick={() => { if (confirm(`Hapus kategori "${cat.name}"?`)) deleteMutation.mutate({ id: cat.id }); }}
                      className="w-8 h-8 rounded-xl bg-muted flex items-center justify-center hover:bg-destructive hover:text-destructive-foreground transition-colors">
                      <Trash2 size={13} className="text-muted-foreground" />
                    </button>
                  </div>
                </motion.div>
              ))}
            </div>
          )}
      </div>
      <CategoryModal open={modalOpen} onClose={() => setModalOpen(false)} category={editCat} />
    </Layout>
  );
}
