import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Plus, Search, Users, X, Loader2, Trash2, Edit2, QrCode } from "lucide-react";
import { useListMembers, useCreateMember, useUpdateMember, useDeleteMember, getListMembersQueryKey } from "@workspace/api-client-react";
import type { Member } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import Layout from "@/components/layout";
import { formatDate, formatCurrency } from "@/lib/format";
import { QRCodeSVG } from "qrcode.react";

function MemberModal({ open, onClose, member }: { open: boolean; onClose: () => void; member?: Member }) {
  const qc = useQueryClient();
  const createMutation = useCreateMember({ mutation: { onSuccess: () => { qc.invalidateQueries({ queryKey: getListMembersQueryKey() }); toast.success("Anggota ditambahkan"); onClose(); }, onError: () => toast.error("Gagal menambahkan anggota") } });
  const updateMutation = useUpdateMember({ mutation: { onSuccess: () => { qc.invalidateQueries({ queryKey: getListMembersQueryKey() }); toast.success("Anggota diperbarui"); onClose(); }, onError: () => toast.error("Gagal memperbarui anggota") } });
  const [form, setForm] = useState({ name: member?.name ?? "", email: member?.email ?? "", phone: member?.phone ?? "", address: member?.address ?? "" });
  function set(k: string, v: string) { setForm(f => ({ ...f, [k]: v })); }
  const isLoading = createMutation.isPending || updateMutation.isPending;

  return (
    <AnimatePresence>
      {open && (
        <div className="fixed inset-0 z-50 flex items-end md:items-center justify-center">
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="absolute inset-0 bg-black/50 backdrop-blur-sm" onClick={onClose} />
          <motion.div initial={{ scale: 0.95, opacity: 0, y: 20 }} animate={{ scale: 1, opacity: 1, y: 0 }} exit={{ scale: 0.95, opacity: 0, y: 20 }}
            className="relative bg-card border border-border rounded-t-3xl md:rounded-3xl shadow-xl w-full md:max-w-md max-h-[90vh] overflow-y-auto">
            <div className="sticky top-0 bg-card border-b border-border px-6 py-4 flex items-center justify-between rounded-t-3xl">
              <h2 className="text-base font-semibold" style={{ fontFamily: "'Outfit', sans-serif" }}>{member ? "Edit Anggota" : "Tambah Anggota"}</h2>
              <button onClick={onClose} className="p-1.5 rounded-xl hover:bg-accent"><X size={16} className="text-muted-foreground" /></button>
            </div>
            <form onSubmit={e => { e.preventDefault(); const payload = { name: form.name, email: form.email || undefined, phone: form.phone || undefined, address: form.address || undefined }; if (member) updateMutation.mutate({ id: member.id, data: payload }); else createMutation.mutate({ data: payload }); }} className="p-6 space-y-4">
              {[{ label: "Nama Lengkap", key: "name", req: true }, { label: "Email", key: "email" }, { label: "Nomor HP", key: "phone" }].map(f => (
                <div key={f.key}>
                  <label className="block text-xs font-medium text-muted-foreground mb-1">{f.label}{f.req && " *"}</label>
                  <input value={(form as Record<string, string>)[f.key]} onChange={e => set(f.key, e.target.value)} required={f.req}
                    className="w-full px-3.5 py-2.5 bg-background border border-border rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-primary/30 focus:border-primary transition-all" />
                </div>
              ))}
              <div>
                <label className="block text-xs font-medium text-muted-foreground mb-1">Alamat</label>
                <textarea value={form.address} onChange={e => set("address", e.target.value)} rows={2} placeholder="Alamat lengkap..."
                  className="w-full px-3.5 py-2.5 bg-background border border-border rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-primary/30 focus:border-primary resize-none transition-all" />
              </div>
              <motion.button type="submit" disabled={isLoading} whileHover={{ scale: 1.01 }} whileTap={{ scale: 0.98 }}
                className="w-full py-3 bg-primary text-primary-foreground rounded-2xl text-sm font-semibold disabled:opacity-70 flex items-center justify-center gap-2">
                {isLoading ? <><Loader2 size={14} className="animate-spin" /> Menyimpan...</> : (member ? "Simpan Perubahan" : "Tambah Anggota")}
              </motion.button>
            </form>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
}

function QRModal({ member, onClose }: { member: Member; onClose: () => void }) {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="absolute inset-0 bg-black/50 backdrop-blur-sm" onClick={onClose} />
      <motion.div initial={{ scale: 0.9, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} className="relative bg-card border border-border rounded-3xl p-7 shadow-xl text-center max-w-xs w-full">
        <button onClick={onClose} className="absolute top-4 right-4 p-1.5 rounded-xl hover:bg-accent"><X size={16} className="text-muted-foreground" /></button>
        <div className="w-10 h-10 rounded-2xl bg-primary/10 flex items-center justify-center mx-auto mb-3">
          <QrCode size={18} className="text-primary" />
        </div>
        <h3 className="text-sm font-semibold text-foreground mb-1" style={{ fontFamily: "'Outfit', sans-serif" }}>QR Code Anggota</h3>
        <p className="text-xs text-muted-foreground mb-4">{member.name} — {member.memberNumber}</p>
        <div className="flex justify-center p-4 bg-white rounded-2xl border border-border">
          <QRCodeSVG value={member.memberNumber} size={150} />
        </div>
        <p className="text-[10px] text-muted-foreground mt-3">{member.memberNumber}</p>
      </motion.div>
    </div>
  );
}

export default function MembersPage() {
  const qc = useQueryClient();
  const [search, setSearch] = useState("");
  const [page, setPage] = useState(1);
  const [modalOpen, setModalOpen] = useState(false);
  const [editMember, setEditMember] = useState<Member | undefined>();
  const [qrMember, setQrMember] = useState<Member | undefined>();

  const params = { search: search || undefined, page, limit: 15 };
  const { data, isLoading } = useListMembers(params, { query: { queryKey: getListMembersQueryKey(params) } });
  const deleteMutation = useDeleteMember({ mutation: { onSuccess: () => { qc.invalidateQueries({ queryKey: getListMembersQueryKey() }); toast.success("Anggota dihapus"); }, onError: () => toast.error("Gagal menghapus anggota") } });

  return (
    <Layout>
      <div className="p-4 md:p-6 max-w-5xl mx-auto">
        <motion.div initial={{ opacity: 0, y: -8 }} animate={{ opacity: 1, y: 0 }} className="mb-5">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-xl font-bold text-foreground" style={{ fontFamily: "'Outfit', sans-serif" }}>Anggota</h1>
              <p className="text-sm text-muted-foreground">{data?.total ?? 0} anggota terdaftar</p>
            </div>
            <motion.button whileHover={{ scale: 1.02 }} whileTap={{ scale: 0.98 }} onClick={() => { setEditMember(undefined); setModalOpen(true); }}
              data-testid="button-add-member"
              className="flex items-center gap-1.5 px-4 py-2 bg-primary text-primary-foreground rounded-xl text-sm font-semibold shadow-sm">
              <Plus size={15} /> Tambah
            </motion.button>
          </div>
        </motion.div>

        <div className="relative mb-5">
          <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
          <input value={search} onChange={e => { setSearch(e.target.value); setPage(1); }} placeholder="Cari nama anggota..."
            className="w-full pl-9 pr-3 py-2.5 bg-card border border-border rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-primary/30 focus:border-primary transition-all" />
        </div>

        {isLoading ? (
          <div className="space-y-3">{[...Array(5)].map((_, i) => <div key={i} className="bg-card border border-border rounded-2xl h-20 animate-pulse" />)}</div>
        ) : (data?.data ?? []).length === 0 ? (
          <div className="flex flex-col items-center py-16"><Users size={48} className="text-muted-foreground/30 mb-3" /><p className="text-sm text-muted-foreground">Tidak ada anggota ditemukan</p></div>
        ) : (
          <div className="space-y-3">
            {(data?.data ?? []).map((member, i) => (
              <motion.div key={member.id} data-testid={`card-member-${member.id}`}
                initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.04 }}
                className="bg-card border border-border rounded-2xl p-4 shadow-sm flex items-center gap-3">
                <div className="w-10 h-10 rounded-2xl bg-primary/10 flex items-center justify-center flex-shrink-0">
                  <span className="text-sm font-bold text-primary">{member.name.charAt(0)}</span>
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-semibold text-foreground">{member.name}</p>
                  <div className="flex items-center gap-2 flex-wrap mt-0.5">
                    <span className="text-xs text-muted-foreground">{member.memberNumber}</span>
                  </div>
                  <div className="flex items-center gap-3 mt-1 text-[10px] text-muted-foreground">
                    <span>{member.borrowCount ?? 0} peminjaman</span>
                    {(member.fine ?? 0) > 0 && <span className="text-red-500 font-medium">{formatCurrency(member.fine ?? 0)}</span>}
                  </div>
                </div>
                <div className="flex items-center gap-1.5">
                  <button onClick={() => setQrMember(member)} className="w-8 h-8 rounded-xl bg-muted flex items-center justify-center hover:bg-accent transition-colors">
                    <QrCode size={14} className="text-muted-foreground" />
                  </button>
                  <button onClick={() => { setEditMember(member); setModalOpen(true); }} className="w-8 h-8 rounded-xl bg-muted flex items-center justify-center hover:bg-accent transition-colors">
                    <Edit2 size={14} className="text-muted-foreground" />
                  </button>
                  <button onClick={() => { if (confirm(`Hapus anggota "${member.name}"?`)) deleteMutation.mutate({ id: member.id }); }}
                    className="w-8 h-8 rounded-xl bg-muted flex items-center justify-center hover:bg-destructive hover:text-destructive-foreground transition-colors">
                    <Trash2 size={14} className="text-muted-foreground" />
                  </button>
                </div>
              </motion.div>
            ))}
          </div>
        )}

        {(data?.total ?? 0) > 15 && (
          <div className="flex justify-center gap-2 mt-6">
            <button disabled={page === 1} onClick={() => setPage(p => p - 1)} className="px-4 py-2 rounded-xl text-sm font-medium border border-border bg-card hover:bg-accent disabled:opacity-40">Sebelumnya</button>
            <span className="px-4 py-2 text-sm text-muted-foreground">Halaman {page}</span>
            <button disabled={(data?.data.length ?? 0) < 15} onClick={() => setPage(p => p + 1)} className="px-4 py-2 rounded-xl text-sm font-medium border border-border bg-card hover:bg-accent disabled:opacity-40">Berikutnya</button>
          </div>
        )}
      </div>
      <MemberModal open={modalOpen} onClose={() => setModalOpen(false)} member={editMember} />
      {qrMember && <QRModal member={qrMember} onClose={() => setQrMember(undefined)} />}
    </Layout>
  );
}
