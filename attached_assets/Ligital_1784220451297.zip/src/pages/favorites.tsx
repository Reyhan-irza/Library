import { motion, AnimatePresence } from "framer-motion";
import { Heart, BookOpen, Search, Trash2 } from "lucide-react";
import { useState } from "react";
import { useGetFavorites, useRemoveFavorite, getGetFavoritesQueryKey } from "@workspace/api-client-react";
import type { Book } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import Layout from "@/components/layout";
import { cn } from "@/lib/utils";
import BookDetailSheet from "@/components/book-detail-sheet";
import { useGetFavoriteIds, useAddFavorite } from "@workspace/api-client-react";

function StatusBadge({ status }: { status: string }) {
  return (
    <span className={cn(
      "inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-semibold",
      status === "available"
        ? "bg-emerald-100 text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-400"
        : "bg-amber-100 text-amber-700 dark:bg-amber-900/30 dark:text-amber-400",
    )}>
      {status === "available" ? "Tersedia" : "Dipinjam"}
    </span>
  );
}

export default function FavoritesPage() {
  const qc = useQueryClient();
  const [search, setSearch] = useState("");
  const [selectedBook, setSelectedBook] = useState<Book | null>(null);
  const [sheetOpen, setSheetOpen] = useState(false);

  const { data: favorites = [], isLoading } = useGetFavorites({ query: { queryKey: getGetFavoritesQueryKey() } });
  const { data: favoriteIds = [] } = useGetFavoriteIds();

  const removeMutation = useRemoveFavorite({
    mutation: {
      onSuccess: () => {
        qc.invalidateQueries({ queryKey: getGetFavoritesQueryKey() });
        toast.success("Dihapus dari favorit");
      },
      onError: () => toast.error("Gagal menghapus favorit"),
    },
  });

  const addMutation = useAddFavorite({
    mutation: {
      onSuccess: () => {
        qc.invalidateQueries({ queryKey: getGetFavoritesQueryKey() });
        toast.success("Ditambahkan ke favorit");
      },
      onError: () => toast.error("Gagal menambahkan favorit"),
    },
  });

  const filtered = (favorites as Book[]).filter(b =>
    !search ||
    b.title.toLowerCase().includes(search.toLowerCase()) ||
    b.author.toLowerCase().includes(search.toLowerCase()),
  );

  function openDetail(book: Book) {
    setSelectedBook(book);
    setSheetOpen(true);
  }

  function handleToggleFavorite(book: Book) {
    const isFav = (favoriteIds as number[]).includes(book.id);
    if (isFav) {
      removeMutation.mutate({ bookId: book.id });
    } else {
      addMutation.mutate({ data: { bookId: book.id } });
    }
  }

  return (
    <Layout>
      <div className="p-4 md:p-6 max-w-5xl mx-auto">

        {/* Header */}
        <motion.div initial={{ opacity: 0, y: -8 }} animate={{ opacity: 1, y: 0 }} className="mb-5">
          <div className="flex items-center gap-3 mb-1">
            <div className="w-8 h-8 rounded-xl bg-rose-500/10 flex items-center justify-center">
              <Heart size={16} className="text-rose-500" fill="currentColor" />
            </div>
            <div>
              <h1 className="text-xl font-bold text-foreground" style={{ fontFamily: "'Outfit', sans-serif" }}>
                Buku Favorit
              </h1>
              <p className="text-sm text-muted-foreground">{filtered.length} buku tersimpan</p>
            </div>
          </div>
        </motion.div>

        {/* Search */}
        <div className="relative mb-5">
          <Search size={14} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-muted-foreground pointer-events-none" />
          <input
            value={search}
            onChange={e => setSearch(e.target.value)}
            placeholder="Cari buku favorit..."
            className="w-full pl-10 pr-4 py-2.5 bg-card border border-border rounded-2xl text-sm text-foreground placeholder:text-muted-foreground focus:outline-none transition-all duration-200"
          />
        </div>

        {/* Grid */}
        {isLoading ? (
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3">
            {[...Array(8)].map((_, i) => (
              <div key={i} className="bg-card border border-border rounded-2xl h-64 animate-pulse" />
            ))}
          </div>
        ) : filtered.length === 0 ? (
          <motion.div
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            className="flex flex-col items-center justify-center py-20 text-center"
          >
            <div className="w-20 h-20 rounded-3xl bg-rose-500/8 flex items-center justify-center mb-4">
              <Heart size={36} className="text-rose-500/30" />
            </div>
            <h3 className="text-base font-semibold text-foreground mb-1" style={{ fontFamily: "'Outfit', sans-serif" }}>
              {search ? "Tidak Ditemukan" : "Belum Ada Favorit"}
            </h3>
            <p className="text-sm text-muted-foreground max-w-xs leading-relaxed">
              {search
                ? `Tidak ada buku favorit yang cocok dengan "${search}"`
                : "Tambahkan buku ke favorit dengan menekan ikon hati pada kartu buku."}
            </p>
          </motion.div>
        ) : (
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3">
            <AnimatePresence mode="popLayout">
              {filtered.map((book, i) => (
                <motion.div
                  key={book.id}
                  layout
                  initial={{ opacity: 0, y: 12 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, scale: 0.95 }}
                  transition={{ delay: i * 0.04 }}
                  whileHover={{ y: -4, transition: { duration: 0.2 } }}
                  className="bg-card border border-border rounded-2xl overflow-hidden shadow-card group cursor-pointer"
                  onClick={() => openDetail(book)}
                >
                  <div className="aspect-[3/4] bg-muted relative overflow-hidden">
                    {book.coverUrl ? (
                      <img src={book.coverUrl} alt={book.title} className="w-full h-full object-cover" />
                    ) : (
                      <div className="w-full h-full flex items-center justify-center bg-gradient-to-br from-primary/10 to-primary/5">
                        <BookOpen size={28} className="text-primary/30" />
                      </div>
                    )}
                    <div className="absolute top-2 left-2">
                      <StatusBadge status={book.status} />
                    </div>
                    <div className="absolute inset-0 bg-black/0 group-hover:bg-black/10 transition-colors duration-200" />
                    {/* Remove favorite button */}
                    <motion.button
                      whileTap={{ scale: 0.85 }}
                      onClick={e => { e.stopPropagation(); removeMutation.mutate({ bookId: book.id } as Parameters<typeof removeMutation.mutate>[0]); }}
                      className="absolute top-2 right-2 w-7 h-7 bg-rose-500 text-white rounded-lg flex items-center justify-center shadow-sm opacity-0 group-hover:opacity-100 transition-opacity"
                    >
                      <Trash2 size={11} />
                    </motion.button>
                    <div className="absolute bottom-2 right-2 w-6 h-6 bg-rose-500/90 text-white rounded-lg flex items-center justify-center">
                      <Heart size={10} fill="currentColor" />
                    </div>
                  </div>
                  <div className="p-3">
                    <p className="text-xs font-semibold text-foreground line-clamp-2 leading-tight">{book.title}</p>
                    <p className="text-[10px] text-muted-foreground mt-1 line-clamp-1">{book.author}</p>
                    {book.categoryName && <p className="text-[10px] text-primary/70 mt-1">{book.categoryName}</p>}
                    <p className="text-[10px] text-muted-foreground mt-1">{book.stock} eks. tersedia</p>
                  </div>
                </motion.div>
              ))}
            </AnimatePresence>
          </div>
        )}
      </div>

      <BookDetailSheet
        book={selectedBook}
        open={sheetOpen}
        onClose={() => setSheetOpen(false)}
        isFavorite={(favoriteIds as number[]).includes(selectedBook?.id ?? -1)}
        onToggleFavorite={handleToggleFavorite}
      />
    </Layout>
  );
}
